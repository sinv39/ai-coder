# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

DeepCodeResearch 是一个基于 **Research First** 理念的智能代码生成系统,通过四个专业化 Agent 协作,从需求分析到代码生成完成整个流程,生成 repo-level 级别的完整代码仓库。 

## 环境配置

### 安装依赖
```bash
pip install -r requirements.txt
```

### 配置 API Key
```bash
export DASHSCOPE_API_KEY="your-api-key"
```

从 [阿里云百炼控制台](https://bailian.console.aliyun.com/) 获取 API Key。

### 启动系统

**Streamlit 界面 (推荐):**
```bash
streamlit run streamlit_app.py
```
访问: http://localhost:8501

**Python 直接使用:**
```python
from backend_core import DeepCodeResearchSystem

system = DeepCodeResearchSystem()
result = system.generate("项目需求描述")
print(result['code_repo'])
```

## 核心架构

### 四Agent协作流程

系统采用四阶段流水线架构:

```
Orchestrator (qwen-max)      → 任务编排和流程控制
    ↓
Research (qwen-long)         → 深度需求分析 (1000万token上下文)
    ↓
Design (qwen-max)            → 系统架构设计
    ↓
Code (qwen-coder-plus)       → 代码生成 + 自调试
```

### 关键组件

**backend_core.py** - 后端核心逻辑
- `DeepCodeResearchSystem`: 主系统入口
- `OrchestratorAgent`: 任务编排
- `ResearchAgent`: 深度研究 (qwen-long, 1000万token)
- `DesignAgent`: 架构设计
- `CodeAgent`: 代码生成和质量检查
- `DocumentParser`: 统一文档解析 (DOCX/PDF/Markdown/Text)
- `MCPTools`: Model Context Protocol 工具集

**streamlit_app.py** - Streamlit 前端
- 参考 Bolt.new 的两栏布局设计
- 左侧: 输入区域 (文本输入/文档上传)
- 右侧: 代码预览和下载
- 实时 Agent 状态显示

### Agent间通信协议

使用标准化的 `AgentMessage` 数据类:
```python
@dataclass
class AgentMessage:
    msg_type: MessageType      # 消息类型
    sender: str                 # 发送方
    receiver: str               # 接收方
    content: Dict[str, Any]     # 消息内容
```

消息类型定义在 `MessageType` 枚举中:
- `TASK_ASSIGNMENT`: 任务分配
- `RESEARCH_REQUEST/RESULT`: 研究请求/结果
- `DESIGN_REQUEST/RESULT`: 设计请求/结果
- `CODE_REQUEST/RESULT`: 代码请求/结果

### 模型配置

系统使用阿里云百炼平台提供的通义千问系列模型:

| Agent | 模型 | 上下文长度 | 用途 |
|-------|------|----------|------|
| Orchestrator | qwen-max | 32K | 任务规划和协调 |
| Research | qwen-long | **1000万** | 超长文档分析和深度研究 |
| Design | qwen-max | 32K | 架构设计和模块规划 |
| Code | qwen-coder-plus | 32K | 代码生成和调试 |

所有 Agent 通过 OpenAI 兼容接口调用,base_url 为: `https://dashscope.aliyuncs.com/compatible-mode/v1`

## 开发指南

### 添加新 Agent

继承 `BaseAgent` 类并实现 `process` 方法:

```python
class NewAgent(BaseAgent):
    SYSTEM_PROMPT = """你的系统提示..."""

    def process(self, msg: AgentMessage) -> Any:
        # 实现 Agent 逻辑
        messages = [
            {"role": "system", "content": self.SYSTEM_PROMPT},
            {"role": "user", "content": "..."}
        ]
        response = self.call_llm(messages)
        return result
```

在 `AGENTS_CONFIG` 中添加配置:
```python
AGENTS_CONFIG = {
    'new_agent': AgentConfig(
        name="NewAgent",
        model="qwen-max",
        api_key=os.getenv("DASHSCOPE_API_KEY")
    )
}
```

### 扩展文档解析器

在 `DocumentParser` 类中添加新的解析方法:

```python
@staticmethod
def parse_new_format(file_path: str) -> str:
    # 实现解析逻辑
    return parsed_content
```

在 `parse()` 方法中注册新格式:
```python
elif ext == 'new_ext':
    return cls.parse_new_format(file_path)
```

### 添加 MCP 工具

在 `MCPTools` 类中添加静态方法:

```python
@staticmethod
def new_tool(params) -> Dict[str, Any]:
    # 实现工具逻辑
    return {
        "tool": "new_tool",
        "result": result
    }
```

Agent 可通过 `self.mcp.new_tool(params)` 调用。

## 输入输出规范

### 支持的输入格式

- DOCX 文档
- PDF 文档
- Markdown 文件 (.md)
- 纯文本文件 (.txt)

### 生成的输出结构

系统生成完整的代码仓库,典型结构:

```
generated_repo/
├── README.md                 # 项目文档
├── requirements.txt          # Python 依赖
├── .gitignore               # Git 配置
├── Dockerfile               # Docker 配置
├── src/
│   ├── __init__.py
│   ├── main.py              # 主程序
│   ├── models.py            # 数据模型
│   ├── config.py            # 配置
│   └── api/
│       └── routes.py        # API 路由
└── tests/
    ├── __init__.py
    └── test_main.py         # 单元测试
```

### 系统生成流程的数据流

1. **输入解析**: 文档 → 统一文本格式
2. **任务规划**: Orchestrator 分析需求 → 执行计划
3. **深度研究**: Research 分析需求 → 结构化研究报告 (JSON)
4. **架构设计**: Design 基于研究 → 设计文档 (JSON)
5. **代码生成**: Code 基于设计 → 代码仓库 (Dict[str, str])
6. **质量检查**: Code Agent 自调试 → 最终代码
7. **输出交付**: ZIP 下载

## 重要文档

- `ARCHITECTURE.md`: 完整技术架构文档
- `agent_collaboration_flow.mermaid`: Agent 协作流程图
- `research_agent_detail.mermaid`: Research Agent 详细流程
- `design_code_agent_detail.mermaid`: Design/Code Agent 流程

## 注意事项

### Research Agent 的超长上下文能力

Research Agent 使用 qwen-long 模型,支持 1000万 token 上下文,适合:
- 处理超大需求文档 (100+ 页)
- 跨段落深度推理
- 复杂依赖关系分析
- 隐含需求挖掘

### Code Agent 的自调试流程

Code Agent 生成代码后会自动执行质量检查:
1. 使用 `MCPTools.code_analysis()` 进行静态分析
2. 检测语法、类型、风格问题
3. 自动修复常见问题
4. 迭代直到代码质量达标

### Streamlit 前端状态管理

使用 `st.session_state` 管理应用状态:
- `messages`: 消息历史
- `generated_repo`: 生成的代码仓库 (Dict[str, str])
- `agent_status`: Agent 工作状态
- `current_phase`: 当前执行阶段

## API 调用示例

### 基本使用

```python
from backend_core import DeepCodeResearchSystem

system = DeepCodeResearchSystem()

requirement = """
创建任务管理Web应用:
- FastAPI后端
- React前端
- PostgreSQL数据库
- JWT认证
"""

result = system.generate(
    user_input=requirement,
    input_type="text",
    callback=lambda agent, status: print(f"{agent}: {status}")
)

# 访问生成的代码
code_repo = result['code_repo']
for file_path, content in code_repo.items():
    print(f"File: {file_path}")
    print(content)
```

### 从文件生成

```python
result = system.generate(
    user_input="/path/to/requirement.docx",
    input_type="file"
)
```

### 使用回调函数跟踪进度

```python
def status_callback(agent_name, status):
    print(f"[{agent_name}] Status: {status}")

result = system.generate(
    user_input=requirement,
    callback=status_callback
)
```
