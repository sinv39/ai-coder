#!/usr/bin/env python3
"""
自动化重构脚本
将 backend_core.py 拆分到模块化结构
"""

import os
import shutil
from pathlib import Path

print("开始执行自动化重构...")
print("="*70)

# 读取原文件
with open('backend_core.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

def write_module(filename, start, end, imports_extra=""):
    """提取并写入模块"""
    content = ''.join(lines[start:end])
    
    # 添加基础 imports
    header = f'''"""
{filename.split('/')[-1].replace('.py', '').title()} 模块
从 backend_core.py 重构而来
"""

{imports_extra}
'''
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(header + content)
    print(f"✓ 创建: {filename} ({end-start} 行)")

# 1. parser.py
parser_imports = """import docx
import PyPDF2
"""
write_module('src/utils/parser.py', 258, 304, parser_imports)

# 2. mcp_tools.py  
mcp_imports = """from typing import Dict, Any
"""
write_module('src/utils/mcp_tools.py', 310, 344, mcp_imports)

print("✓ utils 模块拆分完成")
print()

