"""
Agent 日志记录器模块
提供结构化的日志记录功能,支持文件和控制台输出
"""

import logging
from datetime import datetime
from pathlib import Path


class AgentLogger:
    """Agent 专用结构化日志记录器"""

    def __init__(self, agent_name: str, log_level=logging.INFO):
        self.agent_name = agent_name
        self.logger = logging.getLogger(f"Agent.{agent_name}")
        self.logger.setLevel(log_level)

        # 避免重复添加 handler
        if not self.logger.handlers:
            # 控制台 handler - 彩色输出
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(
                logging.Formatter(
                    '[%(asctime)s] [%(name)s] %(levelname)s - %(message)s',
                    datefmt='%H:%M:%S'
                )
            )
            self.logger.addHandler(console_handler)

            # 创建 logs 目录
            Path('logs').mkdir(exist_ok=True)

            # 文件 handler - 详细日志
            file_handler = logging.FileHandler(
                f'logs/agent_{agent_name.lower()}_{datetime.now():%Y%m%d}.log',
                encoding='utf-8'
            )
            file_handler.setFormatter(
                logging.Formatter(
                    '[%(asctime)s] %(levelname)s - %(message)s'
                )
            )
            self.logger.addHandler(file_handler)

    def info(self, message: str):
        """记录信息"""
        self.logger.info(message)

    def debug(self, message: str):
        """记录调试信息"""
        self.logger.debug(message)

    def warning(self, message: str):
        """记录警告"""
        self.logger.warning(message)

    def error(self, message: str):
        """记录错误"""
        self.logger.error(message)

    def log_llm_call(self, prompt: str, response: str, duration: float, model: str):
        """记录 LLM 调用详情"""
        self.logger.info(f"LLM 调用完成 (模型: {model}, 耗时: {duration:.2f}s)")
        self.logger.debug(f"Prompt 长度: {len(prompt)} 字符")
        self.logger.debug(f"Response 长度: {len(response)} 字符")

        # 保存完整 prompt 和 response 到独立文件
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

        prompt_file = f'logs/{self.agent_name}_prompt_{timestamp}.txt'
        with open(prompt_file, 'w', encoding='utf-8') as f:
            f.write(f"=== LLM Prompt ===\n")
            f.write(f"Agent: {self.agent_name}\n")
            f.write(f"Model: {model}\n")
            f.write(f"Time: {datetime.now()}\n")
            f.write(f"Length: {len(prompt)} chars\n")
            f.write(f"\n{'='*70}\n\n")
            f.write(prompt)

        response_file = f'logs/{self.agent_name}_response_{timestamp}.txt'
        with open(response_file, 'w', encoding='utf-8') as f:
            f.write(f"=== LLM Response ===\n")
            f.write(f"Agent: {self.agent_name}\n")
            f.write(f"Model: {model}\n")
            f.write(f"Time: {datetime.now()}\n")
            f.write(f"Length: {len(response)} chars\n")
            f.write(f"Duration: {duration:.2f}s\n")
            f.write(f"\n{'='*70}\n\n")
            f.write(response)

        self.logger.debug(f"完整 prompt 保存到: {prompt_file}")
        self.logger.debug(f"完整 response 保存到: {response_file}")

    def log_message(self, msg, direction: str):
        """记录 Agent 消息传递"""
        self.logger.info(
            f"{direction} {msg.msg_type.value}: "
            f"{msg.sender} → {msg.receiver}"
        )

    def log_fallback(self, reason: str):
        """记录 fallback 使用"""
        self.logger.warning(f"⚠️  使用 fallback 生成器: {reason}")
