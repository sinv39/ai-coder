"""
文档解析器模块
支持DOCX, PDF, Markdown, Text等格式的文档解析
"""

import docx
import PyPDF2


class DocumentParser:
    """统一的文档解析接口"""
    
    @staticmethod
    def parse_docx(file_path: str) -> str:
        """解析DOCX文件"""
        doc = docx.Document(file_path)
        return '\n'.join([para.text for para in doc.paragraphs])
    
    @staticmethod
    def parse_pdf(file_path: str) -> str:
        """解析PDF文件"""
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            text = []
            for page in pdf_reader.pages:
                text.append(page.extract_text())
            return '\n'.join(text)
    
    @staticmethod
    def parse_markdown(file_path: str) -> str:
        """解析Markdown文件"""
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    
    @staticmethod
    def parse_text(file_path: str) -> str:
        """解析文本文件"""
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    
    @classmethod
    def parse(cls, file_path: str) -> str:
        """根据文件类型自动选择解析器"""
        ext = file_path.split('.')[-1].lower()
        
        if ext == 'docx':
            return cls.parse_docx(file_path)
        elif ext == 'pdf':
            return cls.parse_pdf(file_path)
        elif ext in ['md', 'markdown']:
            return cls.parse_markdown(file_path)
        elif ext == 'txt':
            return cls.parse_text(file_path)
        else:
            raise ValueError(f"不支持的文件格式: {ext}")
