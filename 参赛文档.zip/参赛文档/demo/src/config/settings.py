"""
配置加载模块
负责从环境变量或.env文件加载API Key
"""

import os
from typing import Optional
from pathlib import Path


def load_api_key() -> Optional[str]:
    """
    加载 API Key,优先级:
    1. 环境变量 DASHSCOPE_API_KEY
    2. .env 文件
    3. 项目根目录的 .env 文件
    """
    # 1. 尝试从环境变量获取
    api_key = os.getenv("DASHSCOPE_API_KEY")
    if api_key:
        print(f"✓ 从环境变量加载 API Key")
        return api_key

    # 2. 尝试从当前目录的 .env 文件加载
    env_files = [
        Path.cwd() / '.env',  # 当前工作目录
        Path(__file__).parent.parent.parent / '.env',  # 项目根目录(从src/config/)
    ]

    for env_file in env_files:
        if env_file.exists():
            try:
                with open(env_file, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        # 跳过注释和空行
                        if not line or line.startswith('#'):
                            continue
                        # 解析 KEY=VALUE 格式
                        if '=' in line:
                            key, value = line.split('=', 1)
                            key = key.strip()
                            value = value.strip().strip('"').strip("'")  # 移除引号
                            if key == 'DASHSCOPE_API_KEY' and value:
                                print(f"✓ 从 {env_file} 加载 API Key")
                                return value
            except Exception as e:
                print(f"警告: 读取 {env_file} 失败: {e}")
                continue

    # 3. 都没有找到
    print("❌ 未找到 DASHSCOPE_API_KEY")
    print("请配置 API Key:")
    print("  方法1: 设置环境变量 export DASHSCOPE_API_KEY='your-key'")
    print("  方法2: 在项目根目录创建 .env 文件,内容: DASHSCOPE_API_KEY=your-key")
    return None
