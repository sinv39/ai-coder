"""
Agent配置模块
定义Agent的配置类和预设配置
"""

from dataclasses import dataclass
from .settings import load_api_key


@dataclass
class AgentConfig:
    """Agent配置"""
    name: str
    model: str
    api_key: str
    base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    max_tokens: int = 4096
    temperature: float = 0.7


# 加载 API Key
_API_KEY = load_api_key()

# Agent配置
AGENTS_CONFIG = {
    'orchestrator': AgentConfig(
        name="Orchestrator",
        model="qwen-max",
        api_key=_API_KEY,
        max_tokens=4096,
        temperature=0.7
    ),
    'research': AgentConfig(
        name="Research",
        model="qwen-long",
        api_key=_API_KEY,
        max_tokens=8192,  # API 限制最大 8192
        temperature=0.3
    ),
    'design': AgentConfig(
        name="Design",
        model="qwen-max",
        api_key=_API_KEY,
        max_tokens=8192,
        temperature=0.5
    ),
    'code': AgentConfig(
        name="Code",
        model="qwen-coder-plus",
        api_key=_API_KEY,
        max_tokens=8192,
        temperature=0.2
    )
}
