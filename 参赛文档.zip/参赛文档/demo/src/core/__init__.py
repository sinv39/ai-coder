"""核心系统模块"""

from .messages import MessageType, AgentMessage

__all__ = ["MessageType", "AgentMessage"]
