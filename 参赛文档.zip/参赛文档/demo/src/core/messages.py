"""
Agent消息协议模块
定义Agent间通信的消息类型和数据结构
"""

from enum import Enum
from dataclasses import dataclass, asdict
from typing import Dict, Any


class MessageType(Enum):
    """Agent间消息类型"""
    TASK_ASSIGNMENT = "task_assignment"
    RESEARCH_REQUEST = "research_request"
    RESEARCH_RESULT = "research_result"
    DESIGN_REQUEST = "design_request"
    DESIGN_RESULT = "design_result"
    CODE_REQUEST = "code_request"
    CODE_RESULT = "code_result"


@dataclass
class AgentMessage:
    """Agent通信消息"""
    msg_type: MessageType
    sender: str
    receiver: str
    content: Dict[str, Any]
    
    def to_dict(self) -> Dict:
        data = asdict(self)
        data['msg_type'] = self.msg_type.value
        return data
