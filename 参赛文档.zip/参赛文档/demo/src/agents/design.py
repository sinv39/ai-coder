"""
Design Agent 模块
负责系统架构设计
"""

import re
import json
from typing import Dict, Any
from .base import BaseAgent
from ..core.messages import AgentMessage


class DesignAgent(BaseAgent):
    """架构设计Agent"""

    SYSTEM_PROMPT = """你是系统架构师，负责：
1. 基于研究报告设计系统架构
2. 定义模块结构和接口
3. 选择设计模式和技术方案
4. 输出详细的设计文档

输出JSON格式：
{
  "architecture": {"pattern": "MVC", "layers": []},
  "modules": [{"name": "auth", "description": "..."}],
  "directory_structure": {},
  "interfaces": []
}"""

    def process(self, msg: AgentMessage) -> Dict[str, Any]:
        """执行架构设计"""
        research_result = msg.content.get("research_result", {})

        messages = [
            {"role": "system", "content": self.SYSTEM_PROMPT},
            {"role": "user", "content": f"研究报告:\n{json.dumps(research_result, ensure_ascii=False, indent=2)}\n\n请基于研究报告进行详细的架构设计,输出JSON格式。"}
        ]

        response = self.call_llm(messages)

        # 智能解析设计结果
        result = self._parse_design_result(response, research_result)

        return result

    def _parse_design_result(self, response: str, research: Dict) -> Dict[str, Any]:
        """解析设计结果"""
        # 尝试解析JSON
        try:
            return json.loads(response)
        except:
            pass

        # 从代码块提取
        json_match = re.search(r'```(?:json)?\s*\n(.*?)```', response, re.DOTALL)
        if json_match:
            try:
                return json.loads(json_match.group(1))
            except:
                pass

        # 生成默认设计
        tech_stack = research.get('tech_stack', {})
        requirements = research.get('requirements', [])
        project_type = research.get('project_type', '应用程序')

        # 根据项目类型生成模块
        modules = []
        if '游戏' in project_type:
            modules = [
                {"name": "main", "description": "游戏主程序和主循环"},
                {"name": "game_logic", "description": "游戏逻辑和规则"},
                {"name": "renderer", "description": "游戏渲染和显示"},
                {"name": "input_handler", "description": "用户输入处理"},
                {"name": "config", "description": "游戏配置"}
            ]
        elif 'Web' in project_type or 'API' in project_type:
            modules = [
                {"name": "main", "description": "应用入口"},
                {"name": "api", "description": "API路由"},
                {"name": "models", "description": "数据模型"},
                {"name": "services", "description": "业务逻辑"},
                {"name": "config", "description": "配置管理"}
            ]
        else:
            modules = [
                {"name": "main", "description": "主程序"},
                {"name": "core", "description": "核心逻辑"},
                {"name": "utils", "description": "工具函数"},
                {"name": "config", "description": "配置"}
            ]

        return {
            "project_name": research.get('project_name', 'Generated Project'),
            "description": research.get('description', ''),
            "architecture": {
                "pattern": "模块化设计",
                "layers": ["表示层", "业务逻辑层", "数据层"]
            },
            "modules": modules,
            "tech_stack": tech_stack,
            "directory_structure": self._generate_directory_structure(project_type, modules),
            "interfaces": []
        }

    def _generate_directory_structure(self, project_type: str, modules: list) -> dict:
        """生成目录结构"""
        if '游戏' in project_type:
            return {
                "src/": "源代码目录",
                "src/main.py": "主程序入口",
                "src/game.py": "游戏核心逻辑",
                "src/config.py": "配置文件",
                "tests/": "测试目录",
                "README.md": "项目说明",
                "requirements.txt": "依赖列表"
            }
        else:
            return {
                "src/": "源代码目录",
                "src/main.py": "主程序",
                "src/models.py": "数据模型",
                "src/config.py": "配置",
                "tests/": "测试",
                "README.md": "文档"
            }
