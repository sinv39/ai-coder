"""
Code Agent 模块
负责代码生成,使用 qwen-coder-plus 模型
"""

import re
import json
from typing import Dict, Any
from .base import BaseAgent
from ..core.messages import AgentMessage

class CodeAgent(BaseAgent):
    """代码生成Agent - 使用qwen-coder-plus"""

    SYSTEM_PROMPT = """你是代码生成专家，负责生成完整的repo级别代码仓库。

**重要要求：**
1. 必须基于设计文档生成真实的、可运行的代码
2. 每个文件都要包含完整的实现，不能有TODO或占位符
3. 代码要有完整的功能实现和错误处理
4. 包含单元测试、README、配置文件等

**🚨 依赖库限制 (必须严格遵守!)：**
对于游戏项目，**禁止使用 pygame**，必须使用 Python 标准库 tkinter：
- ✅ **强制使用**: tkinter (Python 自带 GUI 库)
- ✅ 允许使用: random, time, sys, os, threading 等标准库
- ❌ **严格禁止**: pygame, pyglet, arcade (需要编译,安装困难)
- ❌ **严格禁止**: numpy, pandas (非必需的大型库)

**理由**: pygame 在 macOS 上需要 SDL2 库,安装失败率极高,会导致用户无法运行代码!

**tkinter 游戏开发示例**:
```python
import tkinter as tk

class Game:
    def __init__(self, root):
        self.canvas = tk.Canvas(root, width=600, height=400, bg='black')
        self.canvas.pack()
        root.bind('<KeyPress>', self.on_key_press)

    def update(self):
        # 游戏逻辑
        self.canvas.delete('all')  # 清空画布
        # 绘制游戏元素
        self.canvas.create_rectangle(x, y, x+10, y+10, fill='green')
        self.canvas.after(100, self.update)  # 游戏循环
```

**Python 导入规范 (非常重要!)：**
src/ 目录下的文件之间必须使用相对导入:
- ✅ 正确: `from .model import Snake`
- ❌ 错误: `from src.model import Snake` (会导致 ModuleNotFoundError)
- ❌ 错误: `from model import Snake` (如果不在同一目录)

**README 要求 (必须详细!)：**
必须包含完整的运行说明:

```markdown
# 项目名称

## 功能说明
[详细说明项目功能]

## 环境要求
- Python 3.7+
- tkinter (Python 自带,无需安装)

## 安装
无需安装任何依赖! 本项目仅使用 Python 标准库。

## 运行

**重要**: 必须在项目根目录使用模块方式运行:

\```bash
# 运行游戏
python -m src.main
\```

**注意**: 不要使用 `python src/main.py`,会导致导入错误。

## 项目结构
\```
.
├── src/
│   ├── main.py      # 主程序
│   ├── game.py      # 游戏逻辑
│   └── config.py    # 配置
└── tests/
    └── test_game.py # 测试
\```
```

**输出格式：**
请使用以下严格的格式输出代码仓库，每个文件用特殊标记分隔：

```
FILE: path/to/file1.py
```python
# 文件内容
```

FILE: path/to/file2.py
```python
# 文件内容
```

FILE: README.md
```markdown
# 文件内容
```
"""

    def process(self, msg: AgentMessage) -> Dict[str, Any]:
        """生成代码仓库"""
        design_result = msg.content.get("design_result", {})

        self.logger.info("="*70)
        self.logger.info("开始代码生成")
        self.logger.info("="*70)

        # 构建详细的prompt
        user_prompt = self._build_generation_prompt(design_result)
        self.logger.info(f"构建代码生成 prompt, 长度: {len(user_prompt)} 字符")

        messages = [
            {"role": "system", "content": self.SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt}
        ]

        # 调用 LLM (日志已在 call_llm 中记录)
        response = self.call_llm(messages)

        # 解析LLM返回的代码仓库
        self.logger.info("开始解析 LLM 响应...")
        repo = self._parse_llm_response(response, design_result)
        self.logger.info(f"解析完成: 提取到 {len(repo)} 个文件")

        if len(repo) > 0:
            self.logger.info(f"文件列表: {list(repo.keys())[:10]}...")

        # 🔥 改进: 更智能的 fallback 判断
        use_fallback = False
        fallback_reason = ""

        if len(repo) == 0:
            use_fallback = True
            fallback_reason = "LLM 响应解析失败,未提取到任何文件"
        elif len(repo) < 3:
            use_fallback = True
            fallback_reason = f"解析出的文件数量过少({len(repo)}个),可能不完整"
        elif not self._validate_repo_structure(repo):
            use_fallback = True
            fallback_reason = "缺少核心文件 (main.py 或 README.md)"

        if use_fallback:
            self.logger.log_fallback(fallback_reason)
            self.logger.info("切换到 fallback 生成器...")
            repo = self._fallback_generation(design_result)
            self.logger.info(f"Fallback 生成完成: {len(repo)} 个文件")
        else:
            self.logger.info(f"✅ 使用 LLM 生成的代码 ({len(repo)} 个文件)")

        # 代码质量检查
        self._quality_check(repo)

        self.logger.info("="*70)
        self.logger.info(f"代码生成完成: {len(repo)} 个文件")
        self.logger.info("="*70)

        return repo

    def _build_generation_prompt(self, design: Dict) -> str:
        """构建详细的代码生成prompt"""
        prompt = f"""请基于以下设计文档生成完整的代码仓库：

设计文档:
{json.dumps(design, ensure_ascii=False, indent=2)}

**生成要求：**
1. 根据设计文档中的模块结构生成所有必要的文件
2. 每个文件都要有完整的实现（不要TODO或占位符）
3. 包含以下基础文件：
   - README.md (项目说明)
   - requirements.txt 或 package.json (依赖)
   - .gitignore (Git配置)
   - 主程序入口文件
   - 配置文件
   - 测试文件

4. 代码质量要求：
   - 完整的函数/类实现
   - 合理的错误处理
   - 适当的注释
   - 遵循最佳实践

请严格按照以下格式输出每个文件：

FILE: 文件路径
```语言
文件完整内容
```

开始生成代码仓库：
"""
        return prompt

    def _parse_llm_response(self, response: str, design: Dict) -> Dict[str, str]:
        """解析LLM返回的代码仓库 - 增强版"""
        import re

        repo = {}

        self.logger.info("尝试方法1: 标准 'FILE:' 格式解析")

        # 方法1: 使用FILE:标记解析
        file_pattern = r'FILE:\s*([^\n]+)\s*```(\w+)?\s*\n(.*?)```'
        matches = re.findall(file_pattern, response, re.DOTALL)

        if matches:
            self.logger.info(f"方法1 成功: 找到 {len(matches)} 个文件标记")
            for file_path, language, content in matches:
                file_path = file_path.strip()
                content = content.strip()
                repo[file_path] = content
                self.logger.debug(f"  - {file_path} ({len(content)} 字符)")

        # 方法2: 如果方法1失败，尝试查找所有代码块
        if len(repo) == 0:
            self.logger.info("方法1 失败,尝试方法2: 从上下文推断文件名")

            code_block_pattern = r'```(\w+)?\s*\n(.*?)```'
            code_blocks = re.findall(code_block_pattern, response, re.DOTALL)
            self.logger.info(f"找到 {len(code_blocks)} 个代码块")

            # 尝试从文本中提取文件路径
            lines = response.split('\n')
            current_file = None

            for i, line in enumerate(lines):
                # 查找可能的文件路径指示
                if any(marker in line.lower() for marker in ['file:', '文件:', 'filename:', '路径:']):
                    # 提取文件路径
                    path_match = re.search(r'[`"]?([a-zA-Z0-9_./\-]+\.[a-zA-Z]+)[`"]?', line)
                    if path_match:
                        current_file = path_match.group(1)
                        self.logger.debug(f"找到文件路径线索: {current_file}")

                # 查找代码块
                if line.strip().startswith('```') and current_file:
                    # 提取代码块内容
                    block_start = i + 1
                    block_end = block_start

                    for j in range(block_start, len(lines)):
                        if lines[j].strip().startswith('```'):
                            block_end = j
                            break

                    if block_end > block_start:
                        content = '\n'.join(lines[block_start:block_end])
                        repo[current_file] = content
                        self.logger.debug(f"  - {current_file} ({len(content)} 字符)")
                        current_file = None

            if len(repo) > 0:
                self.logger.info(f"方法2 成功: 提取 {len(repo)} 个文件")
            else:
                self.logger.warning("方法2 失败: 未能提取文件")

        # 方法3: JSON 格式
        if len(repo) == 0:
            self.logger.info("尝试方法3: JSON 格式解析")
            try:
                # 尝试提取 JSON 对象
                json_match = re.search(r'```json\s*\n(.*?)```', response, re.DOTALL)
                if json_match:
                    data = json.loads(json_match.group(1))
                    if isinstance(data, dict) and 'files' in data:
                        repo = data['files']
                        self.logger.info(f"方法3 成功: 从 JSON 提取 {len(repo)} 个文件")
            except Exception as e:
                self.logger.debug(f"方法3 失败: {e}")

        if len(repo) == 0:
            self.logger.error("所有解析方法均失败")
            self.logger.debug(f"LLM 响应前1000字符:\n{response[:1000]}")

        return repo

    def _validate_repo_structure(self, repo: Dict[str, str]) -> bool:
        """验证代码仓库结构是否完整"""
        # 检查是否包含关键文件
        has_readme = 'README.md' in repo
        has_main = any(
            'main.py' in f or 'main.js' in f or 'index.js' in f or 'app.py' in f
            for f in repo.keys()
        )

        # 至少要有 README 或主文件之一
        return has_readme or has_main

    def _fallback_generation(self, design: Dict) -> Dict[str, str]:
        """备用代码生成方法 - 基于设计文档生成基础框架"""

        # 从设计文档中提取信息
        tech_stack = design.get('tech_stack', {})
        modules = design.get('modules', [])
        directory_structure = design.get('directory_structure', {})

        # 检测项目类型
        backend = tech_stack.get('backend', '').lower() if isinstance(tech_stack, dict) else ''
        frontend = tech_stack.get('frontend', '').lower() if isinstance(tech_stack, dict) else ''

        repo = {}

        # 生成.gitignore (先生成,README 在生成代码后再生成以确保准确)
        repo['.gitignore'] = """# Python
venv/
__pycache__/
*.pyc
*.pyo
*.pyd
.Python
*.so
*.egg
*.egg-info/
dist/
build/

# IDE
.vscode/
.idea/
*.swp
*.swo

# Environment
.env
.env.local

# OS
.DS_Store
Thumbs.db
"""

        # 根据技术栈和需求描述检测项目类型
        project_type = None
        design_str = json.dumps(design, ensure_ascii=False).lower()

        # 检测游戏项目 - 扩展关键词检测
        is_game = any(keyword in design_str for keyword in [
            '游戏', 'game', '贪吃蛇', 'snake',
            'pygame', 'tkinter', '俄罗斯方块', 'tetris',
            '扫雷', 'minesweeper', '井字棋', 'tic-tac-toe'
        ])

        if is_game:
            project_type = 'game'
            self._generate_pygame_project(repo, design)
        elif 'python' in backend or 'fastapi' in backend or 'flask' in backend:
            project_type = 'python'
            self._generate_python_project(repo, design, backend)
        elif 'node' in backend or 'express' in backend:
            project_type = 'node'
            self._generate_node_project(repo, design)
        elif 'java' in backend or 'spring' in backend:
            project_type = 'java'
            self._generate_java_project(repo, design)
        else:
            # 默认生成Python项目
            project_type = 'python'
            self._generate_python_project(repo, design, 'python')

        # 最后生成 README (确保准确反映实际生成的代码)
        repo['README.md'] = self._generate_readme_for_type(project_type, design, repo)

        return repo

    def _generate_readme_for_type(self, project_type: str, design: Dict, repo: Dict[str, str]) -> str:
        """根据项目类型生成准确的 README"""
        if project_type == 'game':
            return self._generate_game_readme(design, repo)
        elif project_type == 'python':
            return self._generate_python_readme(design, repo)
        else:
            return self._generate_readme(design)

    def _generate_game_readme(self, design: Dict, repo: Dict[str, str]) -> str:
        """生成游戏项目的 README"""
        project_name = design.get('project_name', 'Snake Game')

        readme = f"""# {project_name}

经典贪吃蛇游戏 - 使用 Python 标准库 tkinter 实现

## 游戏说明

使用方向键控制贪吃蛇移动,吃到红色食物会增长并得分,撞到墙壁或自己则游戏结束。

### 控制方式

- **↑** (Up): 向上移动
- **↓** (Down): 向下移动
- **←** (Left): 向左移动
- **→** (Right): 向右移动
- **Space**: 游戏结束后重新开始

## 功能特性

- ✅ 流畅的游戏体验
- ✅ 实时分数显示
- ✅ 碰撞检测
- ✅ 自动重启
- ✅ 简洁的 UI 设计
- ✅ **零外部依赖** - 仅使用 Python 标准库

## 技术栈

- **语言**: Python 3.7+
- **GUI**: tkinter (Python 标准库)
- **测试**: unittest (Python 标准库)

## 快速开始

### 环境要求

- Python 3.7 或更高版本
- tkinter (Python 自带,无需安装)

### 安装

**无需安装任何依赖!** 本项目100%使用 Python 标准库。

```bash
# 克隆或解压项目后,进入项目目录
cd {project_name.lower().replace(' ', '_')}
```

### 运行游戏

**重要**: 必须在项目根目录运行,有以下两种方式:

```bash
# 方法1: 使用 Python 模块方式运行 (推荐)
python -m src.main

# 方法2: 使用启动脚本
chmod +x run.sh
./run.sh
```

**注意事项**:
- ❌ 不要使用 `python src/main.py` (会导致导入错误)
- ✅ 使用 `python -m src.main` (正确的模块运行方式)
- ✅ 或使用提供的 `run.sh` 脚本

### 运行测试

```bash
# 运行所有测试
python -m unittest discover tests

# 运行特定测试
python tests/test_game.py
```

## 项目结构

```
.
├── README.md           # 本文件
├── requirements.txt    # 依赖列表(空,无需依赖!)
├── run.sh             # 启动脚本
├── src/
│   ├── __init__.py
│   ├── main.py        # 程序入口
│   ├── game.py        # 游戏逻辑
│   └── config.py      # 游戏配置
└── tests/
    ├── __init__.py
    └── test_game.py   # 单元测试
```

## 配置说明

可以在 `src/config.py` 中修改游戏配置:

```python
CELL_SIZE = 20         # 格子大小
GRID_WIDTH = 30        # 网格宽度
GRID_HEIGHT = 20       # 网格高度
GAME_SPEED = 100       # 游戏速度(毫秒,越小越快)

# 颜色配置
COLOR_BG = '#1a1a1a'        # 背景色
COLOR_SNAKE = '#00ff00'     # 蛇身颜色
COLOR_FOOD = '#ff0000'      # 食物颜色
```

## 常见问题

### 1. tkinter 未安装?

tkinter 是 Python 的标准库,通常随 Python 一起安装。

**验证 tkinter 是否可用:**
```bash
python -c "import tkinter; print('✅ tkinter 可用')"
```

**如果报错,安装方法:**

```bash
# macOS (通常不需要)
brew install python-tk

# Ubuntu/Debian
sudo apt-get install python3-tk

# CentOS/RHEL
sudo yum install python3-tkinter
```

### 2. 如何修改游戏难度?

编辑 `src/config.py`:

```python
# 简单模式
GAME_SPEED = 150  # 慢速

# 普通模式
GAME_SPEED = 100  # 默认

# 困难模式
GAME_SPEED = 50   # 快速
```

### 3. 如何修改窗口大小?

编辑 `src/config.py`:

```python
GRID_WIDTH = 40   # 更宽
GRID_HEIGHT = 30  # 更高
```

## 开发说明

### 代码结构

- `src/main.py`: 程序入口,创建 tkinter 窗口
- `src/game.py`:
  - `Snake`: 贪吃蛇类,处理移动和碰撞
  - `Food`: 食物类,随机生成位置
  - `SnakeGame`: 游戏主类,处理游戏循环和渲染
- `src/config.py`: 游戏配置常量
- `tests/test_game.py`: 单元测试

### 扩展功能建议

- [ ] 添加难度级别选择
- [ ] 添加最高分记录
- [ ] 添加音效
- [ ] 添加暂停功能
- [ ] 添加多种游戏模式

## 许可证

本项目使用 MIT 许可证

## 致谢

由 DeepCodeResearch 自动生成
"""
        return readme

    def _generate_python_readme(self, design: Dict, repo: Dict[str, str]) -> str:
        """生成 Python 项目的 README"""
        project_name = design.get('project_name', 'Python Project')
        description = design.get('description', 'Generated by DeepCodeResearch')

        # 检测是否是 FastAPI 项目
        requirements = repo.get('requirements.txt', '')
        is_fastapi = 'fastapi' in requirements.lower()

        readme = f"""# {project_name}

{description}

## 快速开始

### 环境要求

- Python 3.8+

### 安装依赖

```bash
pip install -r requirements.txt
```

### 运行

```bash
"""
        if is_fastapi:
            readme += """# 开发模式
uvicorn src.main:app --reload

# 生产模式
uvicorn src.main:app --host 0.0.0.0 --port 8000
```

访问:
- API文档: http://localhost:8000/docs
- 健康检查: http://localhost:8000/
"""
        else:
            readme += """python src/main.py
```
"""

        readme += """
### 运行测试

```bash
pytest tests/ -v
```

## 项目结构

```
.
├── README.md
├── requirements.txt
├── src/
│   ├── __init__.py
│   ├── main.py
│   ├── models.py
│   └── config.py
└── tests/
    └── test_main.py
```

## 许可证

MIT License

---

*Generated by DeepCodeResearch*
"""
        return readme

    def _generate_readme(self, design: Dict) -> str:
        """生成README文件"""
        project_name = design.get('project_name', 'Generated Project')
        description = design.get('description', 'Generated by DeepCodeResearch')

        readme = f"""# {project_name}

{description}

## 功能特性

"""
        # 添加模块说明
        modules = design.get('modules', [])
        if modules:
            for module in modules:
                if isinstance(module, dict):
                    name = module.get('name', 'Module')
                    desc = module.get('description', '')
                    readme += f"- **{name}**: {desc}\n"

        readme += """
## 技术栈

"""
        tech_stack = design.get('tech_stack', {})
        if isinstance(tech_stack, dict):
            for key, value in tech_stack.items():
                readme += f"- **{key.capitalize()}**: {value}\n"

        readme += """
## 安装

```bash
# 安装依赖
pip install -r requirements.txt  # Python项目
# 或
npm install  # Node.js项目
```

## 运行

```bash
# 启动应用
python src/main.py  # Python项目
# 或
npm start  # Node.js项目
```

## 测试

```bash
pytest tests/  # Python项目
# 或
npm test  # Node.js项目
```

## 项目结构

```
.
├── README.md
├── requirements.txt
├── src/
│   ├── main.py
│   ├── models.py
│   └── config.py
└── tests/
    └── test_main.py
```

---

*Generated by DeepCodeResearch*
"""
        return readme

    def _generate_pygame_project(self, repo: Dict[str, str], design: Dict):
        """生成游戏项目 - 使用 tkinter (Python 标准库,无需额外依赖)"""

        project_name = design.get('project_name', 'Snake Game')
        description = design.get('description', '使用 tkinter (Python 标准库) 开发的贪吃蛇游戏')

        # requirements.txt - 完全不需要外部依赖!
        repo['requirements.txt'] = """# 本项目仅使用 Python 标准库,无需安装任何额外依赖
# tkinter 是 Python 自带的 GUI 库,已随 Python 一起安装
"""

        # 贪吃蛇游戏主程序
        repo['src/__init__.py'] = ""
        repo['src/main.py'] = """#!/usr/bin/env python3
\"\"\"
贪吃蛇游戏 - 使用 tkinter 实现
控制: 方向键 ↑↓←→
目标: 吃到红色食物,避免撞墙和撞到自己
\"\"\"

import tkinter as tk
from game import SnakeGame

def main():
    # 创建主窗口
    root = tk.Tk()
    root.title("贪吃蛇游戏")
    root.resizable(False, False)

    # 创建游戏实例
    game = SnakeGame(root)

    # 启动游戏循环
    game.start()

    # 进入 tkinter 事件循环
    root.mainloop()

if __name__ == "__main__":
    main()
"""

        # 游戏核心逻辑
        repo['src/game.py'] = """import tkinter as tk
import random
from typing import List, Tuple
from config import *

class Snake:
    \"\"\"贪吃蛇类\"\"\"

    def __init__(self):
        # 蛇的初始位置(中心)
        start_x = GRID_WIDTH // 2
        start_y = GRID_HEIGHT // 2

        self.body: List[Tuple[int, int]] = [
            (start_x, start_y),
            (start_x - 1, start_y),
            (start_x - 2, start_y)
        ]

        self.direction = 'Right'
        self.next_direction = 'Right'
        self.grow = False

    def change_direction(self, new_direction: str):
        \"\"\"改变移动方向(不能反向)\"\"\"
        opposite = {
            'Up': 'Down',
            'Down': 'Up',
            'Left': 'Right',
            'Right': 'Left'
        }

        if new_direction != opposite.get(self.direction):
            self.next_direction = new_direction

    def move(self):
        \"\"\"移动蛇\"\"\"
        self.direction = self.next_direction
        head_x, head_y = self.body[0]

        # 根据方向计算新头部位置
        if self.direction == 'Up':
            new_head = (head_x, head_y - 1)
        elif self.direction == 'Down':
            new_head = (head_x, head_y + 1)
        elif self.direction == 'Left':
            new_head = (head_x - 1, head_y)
        else:  # Right
            new_head = (head_x + 1, head_y)

        # 添加新头部
        self.body.insert(0, new_head)

        # 如果不需要生长,移除尾部
        if not self.grow:
            self.body.pop()
        else:
            self.grow = False

    def eat(self):
        \"\"\"吃到食物,标记需要生长\"\"\"
        self.grow = True

    def check_collision(self) -> bool:
        \"\"\"检查是否撞墙或撞到自己\"\"\"
        head_x, head_y = self.body[0]

        # 撞墙
        if head_x < 0 or head_x >= GRID_WIDTH or head_y < 0 or head_y >= GRID_HEIGHT:
            return True

        # 撞到自己
        if self.body[0] in self.body[1:]:
            return True

        return False


class Food:
    \"\"\"食物类\"\"\"

    def __init__(self):
        self.position = (0, 0)
        self.spawn()

    def spawn(self):
        \"\"\"在随机位置生成食物\"\"\"
        self.position = (
            random.randint(0, GRID_WIDTH - 1),
            random.randint(0, GRID_HEIGHT - 1)
        )


class SnakeGame:
    \"\"\"贪吃蛇游戏主类 - 使用 tkinter Canvas\"\"\"

    def __init__(self, root: tk.Tk):
        self.root = root
        self.snake = Snake()
        self.food = Food()
        self.score = 0
        self.game_over = False
        self.running = False

        # 创建 Canvas
        self.canvas = tk.Canvas(
            root,
            width=WINDOW_WIDTH,
            height=WINDOW_HEIGHT + 40,  # 额外空间显示分数
            bg=COLOR_BG
        )
        self.canvas.pack()

        # 分数显示
        self.score_text = self.canvas.create_text(
            10, 10,
            text=f"Score: {self.score}",
            fill=COLOR_TEXT,
            font=('Arial', 14),
            anchor='nw'
        )

        # 绑定键盘事件
        self.root.bind('<Up>', lambda e: self.snake.change_direction('Up'))
        self.root.bind('<Down>', lambda e: self.snake.change_direction('Down'))
        self.root.bind('<Left>', lambda e: self.snake.change_direction('Left'))
        self.root.bind('<Right>', lambda e: self.snake.change_direction('Right'))
        self.root.bind('<space>', lambda e: self.restart() if self.game_over else None)

    def start(self):
        \"\"\"启动游戏循环\"\"\"
        self.running = True
        self.game_loop()

    def game_loop(self):
        \"\"\"游戏主循环\"\"\"
        if not self.running:
            return

        if not self.game_over:
            # 更新游戏状态
            self.snake.move()

            # 检查碰撞
            if self.snake.check_collision():
                self.game_over = True
                self.show_game_over()
            else:
                # 检查是否吃到食物
                if self.snake.body[0] == self.food.position:
                    self.snake.eat()
                    self.score += 10

                    # 重新生成食物,确保不在蛇身上
                    while self.food.position in self.snake.body:
                        self.food.spawn()

        # 渲染画面
        self.render()

        # 继续循环
        self.root.after(GAME_SPEED, self.game_loop)

    def render(self):
        \"\"\"渲染游戏画面\"\"\"
        # 清空 Canvas
        self.canvas.delete('game_object')

        # 绘制网格
        self._draw_grid()

        # 绘制食物
        fx, fy = self.food.position
        self.canvas.create_rectangle(
            fx * CELL_SIZE,
            fy * CELL_SIZE + 40,
            (fx + 1) * CELL_SIZE,
            (fy + 1) * CELL_SIZE + 40,
            fill=COLOR_FOOD,
            outline=COLOR_FOOD,
            tags='game_object'
        )

        # 绘制蛇
        for i, (x, y) in enumerate(self.snake.body):
            color = COLOR_SNAKE_HEAD if i == 0 else COLOR_SNAKE
            self.canvas.create_rectangle(
                x * CELL_SIZE,
                y * CELL_SIZE + 40,
                (x + 1) * CELL_SIZE,
                (y + 1) * CELL_SIZE + 40,
                fill=color,
                outline=COLOR_BG,
                tags='game_object'
            )

        # 更新分数
        self.canvas.itemconfig(self.score_text, text=f"Score: {self.score}")

    def _draw_grid(self):
        \"\"\"绘制网格线\"\"\"
        for x in range(0, WINDOW_WIDTH, CELL_SIZE):
            self.canvas.create_line(
                x, 40, x, WINDOW_HEIGHT + 40,
                fill=COLOR_GRID,
                tags='game_object'
            )
        for y in range(0, WINDOW_HEIGHT, CELL_SIZE):
            self.canvas.create_line(
                0, y + 40, WINDOW_WIDTH, y + 40,
                fill=COLOR_GRID,
                tags='game_object'
            )

    def show_game_over(self):
        \"\"\"显示游戏结束提示\"\"\"
        self.canvas.create_text(
            WINDOW_WIDTH // 2,
            WINDOW_HEIGHT // 2 + 20,
            text="GAME OVER",
            fill=COLOR_TEXT,
            font=('Arial', 36, 'bold'),
            tags='game_object'
        )
        self.canvas.create_text(
            WINDOW_WIDTH // 2,
            WINDOW_HEIGHT // 2 + 60,
            text="Press SPACE to restart",
            fill=COLOR_TEXT,
            font=('Arial', 14),
            tags='game_object'
        )

    def restart(self):
        \"\"\"重启游戏\"\"\"
        self.snake = Snake()
        self.food = Food()
        self.score = 0
        self.game_over = False
"""

        # 配置文件
        repo['src/config.py'] = """\"\"\"
游戏配置常量
\"\"\"

# 窗口设置
CELL_SIZE = 20  # 每个格子的像素大小
GRID_WIDTH = 30  # 网格宽度(格子数)
GRID_HEIGHT = 20  # 网格高度(格子数)

WINDOW_WIDTH = CELL_SIZE * GRID_WIDTH  # 窗口宽度(像素)
WINDOW_HEIGHT = CELL_SIZE * GRID_HEIGHT  # 窗口高度(像素)

# 颜色定义 (十六进制)
COLOR_BG = '#1a1a1a'  # 背景色
COLOR_GRID = '#2a2a2a'  # 网格线
COLOR_SNAKE = '#00ff00'  # 蛇身 (绿色)
COLOR_SNAKE_HEAD = '#00cc00'  # 蛇头 (深绿色)
COLOR_FOOD = '#ff0000'  # 食物 (红色)
COLOR_TEXT = '#ffffff'  # 文字 (白色)

# 游戏设置
GAME_SPEED = 100  # 游戏速度(毫秒,数字越小越快)
"""

        # 测试文件
        repo['tests/__init__.py'] = ""
        repo['tests/test_game.py'] = """import unittest
import sys
sys.path.insert(0, 'src')

from game import Snake, Food
from config import GRID_WIDTH, GRID_HEIGHT

class TestSnake(unittest.TestCase):
    \"\"\"测试 Snake 类\"\"\"

    def test_init(self):
        \"\"\"测试蛇的初始化\"\"\"
        snake = Snake()
        self.assertEqual(len(snake.body), 3)
        self.assertEqual(snake.direction, 'Right')

    def test_move(self):
        \"\"\"测试蛇的移动\"\"\"
        snake = Snake()
        initial_head = snake.body[0]
        snake.move()
        new_head = snake.body[0]
        self.assertNotEqual(new_head, initial_head)

    def test_change_direction(self):
        \"\"\"测试改变方向\"\"\"
        snake = Snake()
        snake.change_direction('Up')
        self.assertEqual(snake.next_direction, 'Up')

        # 不能反向
        snake.change_direction('Down')
        self.assertEqual(snake.next_direction, 'Up')

    def test_collision(self):
        \"\"\"测试碰撞检测\"\"\"
        snake = Snake()
        # 模拟撞墙
        snake.body[0] = (-1, 0)
        self.assertTrue(snake.check_collision())


class TestFood(unittest.TestCase):
    \"\"\"测试 Food 类\"\"\"

    def test_spawn(self):
        \"\"\"测试食物生成\"\"\"
        food = Food()
        x, y = food.position
        self.assertGreaterEqual(x, 0)
        self.assertLess(x, GRID_WIDTH)
        self.assertGreaterEqual(y, 0)
        self.assertLess(y, GRID_HEIGHT)


if __name__ == '__main__':
    unittest.main()
"""

        # Dockerfile - 简化版,不需要额外依赖
        repo['Dockerfile'] = """FROM python:3.11-slim

# tkinter 需要一些系统库
RUN apt-get update && apt-get install -y \\
    python3-tk \\
    && rm -rf /var/lib/apt/lists/*

WORKDIR /app

COPY . .

# 注意: GUI 程序在 Docker 中需要 X11 支持
# 本地运行: python src/main.py
CMD ["python", "src/main.py"]
"""

        # 运行脚本
        repo['run.sh'] = """#!/bin/bash
# 运行游戏脚本

echo "启动贪吃蛇游戏..."
echo "控制: 使用方向键 ↑↓←→"
echo ""

# 使用 Python 模块方式运行,避免导入错误
python -m src.main
"""

    def _generate_python_project(self, repo: Dict[str, str], design: Dict, backend: str):
        """生成Python项目代码"""

        # requirements.txt
        if 'fastapi' in backend:
            repo['requirements.txt'] = """fastapi==0.104.1
uvicorn[standard]==0.24.0
pydantic==2.5.0
sqlalchemy==2.0.23
python-multipart==0.0.6
pytest==7.4.3
httpx==0.25.1
"""
            # FastAPI主文件
            repo['src/__init__.py'] = ""
            repo['src/main.py'] = """from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import uvicorn

app = FastAPI(title="Generated API", version="1.0.0")

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 数据模型
class Item(BaseModel):
    id: Optional[int] = None
    name: str
    description: Optional[str] = None

# 内存数据库
items_db: List[Item] = []
next_id = 1

@app.get("/")
async def root():
    return {"message": "Welcome to the API", "status": "running"}

@app.get("/items", response_model=List[Item])
async def get_items():
    return items_db

@app.get("/items/{item_id}", response_model=Item)
async def get_item(item_id: int):
    for item in items_db:
        if item.id == item_id:
            return item
    raise HTTPException(status_code=404, detail="Item not found")

@app.post("/items", response_model=Item)
async def create_item(item: Item):
    global next_id
    item.id = next_id
    next_id += 1
    items_db.append(item)
    return item

@app.put("/items/{item_id}", response_model=Item)
async def update_item(item_id: int, updated_item: Item):
    for i, item in enumerate(items_db):
        if item.id == item_id:
            updated_item.id = item_id
            items_db[i] = updated_item
            return updated_item
    raise HTTPException(status_code=404, detail="Item not found")

@app.delete("/items/{item_id}")
async def delete_item(item_id: int):
    for i, item in enumerate(items_db):
        if item.id == item_id:
            items_db.pop(i)
            return {"message": "Item deleted"}
    raise HTTPException(status_code=404, detail="Item not found")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
"""

        else:
            # 通用Python项目
            repo['requirements.txt'] = """pytest==7.4.3
python-dotenv==1.0.0
"""
            repo['src/__init__.py'] = ""
            repo['src/main.py'] = """#!/usr/bin/env python3
\"\"\"
主程序入口
\"\"\"

def main():
    print("Application started!")
    # 在这里添加你的主要逻辑

if __name__ == "__main__":
    main()
"""

        # 配置文件
        repo['src/config.py'] = """import os
from pathlib import Path
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

class Config:
    \"\"\"应用配置\"\"\"

    # 基础配置
    APP_NAME = os.getenv("APP_NAME", "Generated App")
    DEBUG = os.getenv("DEBUG", "True").lower() == "true"

    # 数据库配置
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./app.db")

    # 安全配置
    SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-here")

    @classmethod
    def get(cls, key: str, default=None):
        return getattr(cls, key, default)

config = Config()
"""

        # 模型文件
        repo['src/models.py'] = """from typing import Optional, List
from pydantic import BaseModel, Field

class BaseEntity(BaseModel):
    \"\"\"基础实体模型\"\"\"
    id: Optional[int] = None

    class Config:
        from_attributes = True

class User(BaseEntity):
    \"\"\"用户模型\"\"\"
    username: str = Field(..., min_length=3, max_length=50)
    email: str = Field(..., pattern=r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$')
    is_active: bool = True

class Item(BaseEntity):
    \"\"\"项目模型\"\"\"
    title: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    owner_id: Optional[int] = None
"""

        # 测试文件
        repo['tests/__init__.py'] = ""
        repo['tests/test_main.py'] = """import pytest
from src.main import *

def test_basic():
    \"\"\"基础测试\"\"\"
    assert True

# 在这里添加更多测试用例
"""

        # Dockerfile
        repo['Dockerfile'] = """FROM python:3.11-slim

WORKDIR /app

# 安装依赖
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# 复制代码
COPY . .

# 运行应用
CMD ["python", "src/main.py"]
"""

        # .env.example
        repo['.env.example'] = """APP_NAME=Generated App
DEBUG=True
DATABASE_URL=sqlite:///./app.db
SECRET_KEY=your-secret-key-here
"""

    def _generate_node_project(self, repo: Dict[str, str], design: Dict):
        """生成Node.js项目代码"""
        repo['package.json'] = """{
  "name": "generated-app",
  "version": "1.0.0",
  "description": "Generated by DeepCodeResearch",
  "main": "src/index.js",
  "scripts": {
    "start": "node src/index.js",
    "dev": "nodemon src/index.js",
    "test": "jest"
  },
  "dependencies": {
    "express": "^4.18.2"
  },
  "devDependencies": {
    "nodemon": "^3.0.1",
    "jest": "^29.7.0"
  }
}"""

        repo['src/index.js'] = """const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: 'API is running' });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = app;
"""

    def _generate_java_project(self, repo: Dict[str, str], design: Dict):
        """生成Java项目代码"""
        repo['pom.xml'] = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.generated</groupId>
    <artifactId>generated-app</artifactId>
    <version>1.0.0</version>
</project>"""

        repo['src/main/java/com/generated/Main.java'] = """package com.generated;

public class Main {
    public static void main(String[] args) {
        System.out.println("Application started!");
    }
}
"""

    def _quality_check(self, repo: Dict[str, str]):
        """代码质量检查"""
        issues = []

        for file_path, content in repo.items():
            if file_path.endswith('.py'):
                # 基础检查
                if 'TODO' in content or 'FIXME' in content:
                    issues.append(f"{file_path}: 包含TODO/FIXME标记")

                if len(content.strip()) < 10:
                    issues.append(f"{file_path}: 文件内容过少")

        if issues:
            print(f"代码质量检查发现 {len(issues)} 个问题:")
            for issue in issues[:5]:  # 只显示前5个
                print(f"  - {issue}")

