"""
Orchestrator Agent 模块
负责任务编排和流程控制
"""

from typing import Dict, Any
from .base import BaseAgent


class OrchestratorAgent(BaseAgent):
    """任务编排Agent"""

    SYSTEM_PROMPT = """你是任务编排专家，负责：
1. 分析用户需求，制定执行计划
2. 协调Research、Design、Code三个Agent
3. 在关键节点进行质量把控
4. 确保最终输出符合要求

请输出JSON格式的任务计划。"""

    def process(self, user_requirement: str) -> Dict[str, Any]:
        """制定任务计划"""
        messages = [
            {"role": "system", "content": self.SYSTEM_PROMPT},
            {"role": "user", "content": f"用户需求:\n{user_requirement}\n\n制定详细的执行计划。"}
        ]

        response = self.call_llm(messages)

        return {
            "plan": response,
            "phases": ["research", "design", "code", "review"]
        }
