"""
Research Agent 模块
负责深度需求分析,使用 qwen-long 的 1000万 token 上下文能力
"""

import re
import json
from typing import Dict, Any
from .base import BaseAgent
from ..core.messages import AgentMessage


class ResearchAgent(BaseAgent):
    """深度研究Agent - 使用qwen-long的1000万token上下文"""

    SYSTEM_PROMPT = """你是深度研究专家，拥有1000万token的超长上下文能力。
职责：
1. 深度分析需求文档（支持超大文档）
2. 提取关键需求和技术约束
3. 进行网络搜索获取最新信息
4. 输出结构化的研究报告

输出JSON格式：
{
  "requirements": ["需求1", "需求2"],
  "tech_stack": {"backend": "FastAPI", "frontend": "React"},
  "constraints": ["约束1", "约束2"],
  "recommendations": ["建议1", "建议2"]
}"""

    def process(self, msg: AgentMessage) -> Dict[str, Any]:
        """执行深度研究"""
        requirement = msg.content.get("requirement", "")

        messages = [
            {"role": "system", "content": self.SYSTEM_PROMPT},
            {"role": "user", "content": f"需求:\n{requirement}\n\n请输出JSON格式的研究报告,包含project_type, project_name, description, requirements, tech_stack, constraints, recommendations等字段。"}
        ]

        response = self.call_llm(messages)

        # 智能解析JSON响应
        result = self._parse_research_result(response, requirement)

        return result

    def _parse_research_result(self, response: str, requirement: str) -> Dict[str, Any]:
        """解析研究结果"""
        # 尝试直接解析JSON
        try:
            return json.loads(response)
        except:
            pass

        # 从代码块中提取JSON
        json_match = re.search(r'```(?:json)?\s*\n(.*?)```', response, re.DOTALL)
        if json_match:
            try:
                return json.loads(json_match.group(1))
            except:
                pass

        # 如果解析失败,生成默认结构
        req_lower = requirement.lower()

        # 智能推断项目类型
        if any(word in req_lower for word in ['游戏', 'game', '贪吃蛇', 'snake']):
            project_type = "游戏"
            backend = "Pygame"
        elif any(word in req_lower for word in ['web', 'api', 'fastapi']):
            project_type = "Web应用"
            backend = "FastAPI"
        else:
            project_type = "应用程序"
            backend = "Python"

        return {
            "project_type": project_type,
            "project_name": "Generated Project",
            "description": requirement[:200] if len(requirement) > 200 else requirement,
            "requirements": [req.strip() for req in requirement.split('\n') if req.strip()][:10],
            "tech_stack": {
                "language": "Python",
                "backend": backend,
                "frontend": "",
                "database": ""
            },
            "constraints": [],
            "recommendations": ["遵循最佳实践", "编写完整代码"]
        }
