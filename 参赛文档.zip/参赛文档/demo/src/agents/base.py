"""
Agent 基类模块
提供所有 Agent 的基础功能,包括 LLM 调用、消息传递和日志记录
"""

import time
from typing import Dict, List, Any
from openai import OpenAI

from ..config.agents import AgentConfig
from ..utils.logger import AgentLogger
from ..utils.mcp_tools import MCPTools
from ..core.messages import AgentMessage


class BaseAgent:
    """Agent基类"""

    def __init__(self, config: AgentConfig):
        self.config = config
        self.client = OpenAI(
            api_key=config.api_key,
            base_url=config.base_url
        )
        self.mcp = MCPTools()
        self.logger = AgentLogger(config.name)

    def call_llm(self, messages: List[Dict[str, str]],
                 stream: bool = False) -> str:
        """调用大模型"""
        start_time = time.time()

        try:
            # 记录调用开始
            prompt = messages[-1]['content'] if messages else ""
            self.logger.info(f"调用 LLM (模型: {self.config.model})...")

            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
                stream=stream
            )

            if stream:
                # 流式响应,收集所有内容
                full_response = ""
                for chunk in response:
                    if chunk.choices[0].delta.content:
                        content = chunk.choices[0].delta.content
                        full_response += content
                content = full_response
            else:
                content = response.choices[0].message.content

            # 记录调用完成
            duration = time.time() - start_time
            self.logger.log_llm_call(prompt, content, duration, self.config.model)

            return content

        except Exception as e:
            self.logger.error(f"LLM 调用失败: {e}")
            return f"Error: {str(e)}"

    def send_message(self, msg: AgentMessage):
        """发送消息"""
        self.logger.log_message(msg, "发送")

    def receive_message(self, msg: AgentMessage) -> Any:
        """接收消息"""
        self.logger.log_message(msg, "接收")
        return self.process(msg)

    def process(self, msg: AgentMessage) -> Any:
        """处理消息 - 由子类实现"""
        raise NotImplementedError
