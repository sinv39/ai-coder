# DeepCodeResearch

**Research First, Then Code** - 基于深度研究的智能代码生成系统

---

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置API Key

**方法1: 使用 .env 文件** (推荐)

```bash
# 复制示例配置文件
cp .env.example .env

# 编辑 .env 文件,填入你的 API Key
# DASHSCOPE_API_KEY=your-api-key-here
```

**方法2: 设置环境变量**

```bash
export DASHSCOPE_API_KEY="your-api-key"
```

获取API Key: [阿里云百炼控制台](https://bailian.console.aliyun.com/)

> **注意**: 系统会自动从以下位置加载 API Key (按优先级):
> 1. 环境变量 `DASHSCOPE_API_KEY`
> 2. 当前目录的 `.env` 文件
> 3. 项目根目录的 `.env` 文件

### 3. 启动系统

**方式1: Streamlit界面** (推荐)

```bash
streamlit run streamlit_app.py
```

访问: http://localhost:8501

**方式2: 直接使用Python**

```python
from backend_core import DeepCodeResearchSystem

system = DeepCodeResearchSystem()

requirement = """
创建一个任务管理Web应用：
- FastAPI后端
- React前端
- PostgreSQL数据库
- JWT认证
"""

result = system.generate(requirement)
print(result['code_repo'])
```

---

## 系统架构

### 四Agent协作

```
Orchestrator (qwen-max)      → 任务编排
    ↓
Research (qwen-long)         → 深度研究 (1000万token上下文)
    ↓
Design (qwen-max)            → 架构设计
    ↓
Code (qwen-coder-plus)       → 代码生成 + 自调试
    ↓
Human Review                 → 质量审核
```

### 支持的输入格式

- ✅ DOCX 文档
- ✅ PDF 文档
- ✅ Markdown 文件
- ✅ 纯文本

### 生成的输出

完整的 **Repo-Level** 代码仓库，包含：

- 源代码文件
- 单元测试
- 配置文件 (requirements.txt, .gitignore)
- 项目文档 (README.md)
- 容器配置 (Dockerfile)

---

## 技术栈

| 组件 | 技术 |
|------|------|
| Agent框架 | ModelScope ms-agent |
| 模型服务 | 阿里云百炼平台 |
| 前端 | Streamlit |
| 后端 | Python 3.8+ |
| 工具协议 | MCP |

### 模型配置

| Agent | 模型 | 上下文长度 |
|-------|------|----------|
| Orchestrator | qwen-max | 32K |
| Research | qwen-long | **1000万** |
| Design | qwen-max | 32K |
| Code | qwen-coder-plus | 32K |

---

## 详细文档

### 核心文档

- 📘 [技术架构文档](ARCHITECTURE.md) - 完整的技术设计
- 📊 [Agent协作流程图](docs/architecture/agent_collaboration_flow.mermaid)
- 🔍 [Research Agent详细流程](docs/architecture/research_agent_detail.mermaid)
- 💻 [Design/Code Agent流程](docs/architecture/design_code_agent_detail.mermaid)
- 📋 [重构进度文档](REFACTORING_PROGRESS.md) - 项目重构状态

### 代码文件

- `streamlit_app.py` - Streamlit前端应用
- `backend_core.py` - 后端核心逻辑
- `requirements.txt` - Python依赖

---

## 使用示例

### 示例1: Web应用

```python
requirement = """
创建博客系统：
- 文章CRUD
- 用户认证
- 评论功能
- FastAPI + React
"""

result = system.generate(requirement)
```

**生成内容**:
```
blog_system/
├── src/
│   ├── main.py
│   ├── models.py
│   ├── api/
│   └── core/
├── tests/
├── requirements.txt
├── README.md
└── Dockerfile
```

### 示例2: 上传文档

在Streamlit界面中：

1. 选择 "上传文档"
2. 上传需求文档 (DOCX/PDF/Markdown)
3. 点击 "开始生成代码"
4. 实时查看Agent工作状态
5. 预览和下载生成的代码

---

## 工作流程

1. **输入解析** - 支持多种格式的需求输入
2. **任务规划** - Orchestrator制定执行计划
3. **深度研究** - Research分析需求和技术栈
4. **架构设计** - Design设计系统架构
5. **代码生成** - Code生成完整代码仓库
6. **质量保证** - 自动调试和测试
7. **输出交付** - ZIP下载完整仓库

详细流程参见: [Agent协作流程图](docs/architecture/agent_collaboration_flow.mermaid)

---

## MCP工具集成

系统集成了以下MCP工具：

- **Web搜索** - 获取最新技术信息
- **代码分析** - 静态代码检查
- **代码执行** - 运行测试验证

---

## 界面预览

Streamlit界面参考 **Bolt.new** 设计：

- 🎨 左右分屏布局
- 📝 左侧：输入区域
- 💻 右侧：代码预览和下载
- 🤖 实时Agent状态指示
- 📊 统计信息展示

---

## 依赖说明

主要依赖：

```
openai>=1.0.0              # OpenAI兼容接口
streamlit>=1.30.0          # Web界面
python-docx>=0.8.11        # DOCX解析
PyPDF2>=3.0.0              # PDF解析
ms-agent>=1.0.0            # Agent框架
```

完整依赖参见: [requirements.txt](requirements.txt)

---

## 项目结构

```
DeepCodeResearch/
├── README.md                     # 项目说明(本文档)
├── ARCHITECTURE.md               # 技术架构文档
├── CLAUDE.md                     # AI开发指令
├── requirements.txt              # Python依赖
├── .env.example                  # 环境变量模板
├── .gitignore                    # Git配置
├── start.sh                      # 启动脚本
│
├── backend_core.py               # 🔥 后端核心逻辑(主文件)
├── streamlit_app.py              # 🎨 Streamlit前端应用
│
├── src/                          # 📦 源代码模块(模块化架构)
│   ├── agents/ ✅                 # Agent实现模块
│   │   ├── __init__.py           # 模块导出
│   │   ├── base.py               # BaseAgent基类
│   │   ├── orchestrator.py       # 任务编排Agent
│   │   ├── research.py           # 深度研究Agent
│   │   ├── design.py             # 架构设计Agent
│   │   └── code.py               # 代码生成Agent
│   ├── config/ ✅                 # 配置管理模块
│   │   ├── __init__.py
│   │   ├── settings.py           # API Key加载
│   │   └── agents.py             # Agent配置
│   ├── core/ ✅                   # 核心协议模块
│   │   ├── __init__.py
│   │   └── messages.py           # 消息协议
│   ├── utils/ ✅                  # 工具模块
│   │   ├── __init__.py
│   │   ├── logger.py             # 日志记录器
│   │   ├── parser.py             # 文档解析器
│   │   └── mcp_tools.py          # MCP工具集
│   └── templates/                # 代码模板(预留)
│
├── frontend/                     # 前端组件(待开发)
├── tests/                        # 单元测试(待开发)
├── logs/                         # 运行日志(自动生成)
│
├── docs/                         # 📚 文档目录
│   ├── architecture/             # 架构文档
│   │   ├── agent_collaboration_flow.mermaid
│   │   ├── research_agent_detail.mermaid
│   │   └── design_code_agent_detail.mermaid
│   └── archive/                  # 历史文档归档
│
└── archive/                      # 🗄️ 归档目录
    └── old_tests/                # 旧测试文件
```

> **架构说明**: 项目已完成Agent模块化重构。`backend_core.py` (574行) 作为主系统入口,从 `src/agents/` 导入5个独立Agent模块。模块化进度: **85%** ✅

---

## 开发指南

### 添加新Agent

```python
class NewAgent(BaseAgent):
    def process(self, msg: AgentMessage):
        # 实现Agent逻辑
        return result
```

### 扩展MCP工具

```python
class MCPTools:
    @staticmethod
    def new_tool(params):
        # 实现新工具
        return result
```

### 支持新文件格式

```python
class DocumentParser:
    @staticmethod
    def parse_new_format(file_path):
        # 实现解析逻辑
        return content
```

---

## 相关资源

- [ModelScope ms-agent](https://github.com/modelscope/ms-agent)
- [阿里云百炼平台](https://bailian.console.aliyun.com/)
- [MCP协议规范](https://modelcontextprotocol.io/)
- [Streamlit文档](https://docs.streamlit.io/)

---

**项目作者**: DeepCodeResearch Team
**最后更新**: 2025-11-10 (Agent模块化重构完成 - 85%)
**许可证**: MIT
