# DeepCodeResearch 技术架构文档

## 1. 系统概述

DeepCodeResearch 是一个基于 **Research First** 理念的智能代码生成系统，通过多Agent协作完成从需求分析到代码生成的完整流程，生成 repo-level 级别的代码仓库。

### 1.1 核心特性

- **多Agent协作**: 四个专业化Agent分工协作
- **深度研究驱动**: 研究阶段深入分析需求和技术栈
- **超长上下文**: qwen-long支持1000万token上下文
- **Repo级别生成**: 生成完整的代码仓库结构
- **多格式输入**: 支持DOCX、PDF、Markdown、文本输入
- **实时可视化**: Streamlit界面实时展示生成过程

### 1.2 技术栈

| 组件 | 技术选型 | 说明 |
|------|---------|------|
| **Agent框架** | ModelScope ms-agent | 多Agent协作框架 |
| **模型服务** | 阿里云百炼平台 | 提供通义千问系列模型 |
| **工具协议** | MCP (Model Context Protocol) | 标准化工具接口 |
| **前端** | Streamlit | 快速构建Web界面 |
| **后端** | Python 3.8+ | 核心业务逻辑 |

---

## 2. 系统架构

### 2.1 整体架构

```
┌─────────────────────────────────────────────────────┐
│              Streamlit Frontend                     │
│          (用户界面 + 实时状态展示)                    │
└──────────────────┬──────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────┐
│            Document Parser                          │
│     (DOCX/PDF/Markdown/Text 统一解析)                │
└──────────────────┬──────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────┐
│         Orchestrator Agent (qwen-max)               │
│              任务编排与流程控制                        │
└──────┬──────────┬──────────┬─────────┬──────────────┘
       │          │           │         │
       ▼          ▼           ▼         ▼
   ┌──────┐  ┌────────┐  ┌───────┐  ┌──────┐
   │Research│ │ Design │  │ Code  │  │Human │
   │qwen-   │ │qwen-   │  │qwen-  │  │Review│
   │long    │ │max     │  │coder+ │  │      │
   └────┬───┘ └───┬────┘  └───┬───┘  └──┬───┘
        │         │            │         │
        ▼         ▼            ▼         ▼
   ┌──────────────────────────────────────────┐
   │         MCP Tools Layer                  │
   │  Web搜索 | 代码分析 | 代码执行            │
   └──────────────────────────────────────────┘
                   │
                   ▼
   ┌──────────────────────────────────────────┐
   │    Generated Repo (ZIP Download)         │
   └──────────────────────────────────────────┘
```

### 2.2 数据流

```
用户输入 → 文档解析 → 需求理解 → 深度研究 → 架构设计 → 代码生成 → 质量检查 → 输出仓库
```

---

## 3. Agent详细设计

### 3.1 Orchestrator Agent

**职责**: 任务编排与流程控制

**模型**: qwen-max

**核心功能**:
1. 解析和理解用户需求
2. 制定详细的执行计划
3. 协调各个Agent的工作
4. 监控执行进度
5. 质量把控

**输入**: 用户需求（文本或文档）

**输出**: 
```json
{
  "plan": "执行计划描述",
  "phases": ["research", "design", "code", "review"],
  "estimated_time": "预估时间"
}
```

**关键特性**:
- 任务分解能力
- 流程控制逻辑
- 异常处理机制

### 3.2 Research Agent

**职责**: 深度需求研究

**模型**: qwen-long (1000万token上下文)

**核心功能**:
1. 处理超大文档（100+页）
2. 深度语义理解和推理
3. 提取功能性和非功能性需求
4. 技术栈调研
5. 约束条件识别
6. 风险评估

**输入**: 原始需求文档/文本

**输出**:
```json
{
  "requirements": [
    {
      "id": "REQ-001",
      "type": "functional",
      "description": "用户登录功能",
      "priority": "high"
    }
  ],
  "tech_stack": {
    "backend": "FastAPI",
    "frontend": "React",
    "database": "PostgreSQL"
  },
  "constraints": [
    {
      "type": "performance",
      "description": "API响应时间<100ms"
    }
  ],
  "architecture_suggestions": {
    "pattern": "Microservices",
    "reasoning": "..."
  },
  "dependencies": {
    "modules": [],
    "external_services": []
  },
  "risks": []
}
```

**工作流程** (参见 research_agent_detail.mermaid):
1. 内容解析与分类
2. 深度分析（利用超长上下文）
3. 外部信息搜索（MCP Web Search）
4. 技术栈分析
5. 约束条件提取
6. 依赖关系建模
7. 风险识别
8. 生成结构化报告

**关键特性**:
- 超长上下文理解
- 跨段落推理
- 隐含需求挖掘
- 矛盾检测

### 3.3 Design Agent

**职责**: 系统架构设计

**模型**: qwen-max

**核心功能**:
1. 架构模式选择
2. 系统分层设计
3. 模块划分
4. 接口设计
5. 数据模型设计
6. 技术选型细化
7. 目录结构规划

**输入**: Research Agent的研究报告

**输出**:
```json
{
  "architecture": {
    "pattern": "MVC",
    "layers": [
      "presentation",
      "business",
      "data",
      "infrastructure"
    ]
  },
  "modules": [
    {
      "name": "auth",
      "description": "用户认证模块",
      "interfaces": [],
      "dependencies": []
    }
  ],
  "directory_structure": {
    "src/": {
      "auth/": ["__init__.py", "models.py", "services.py"],
      "api/": ["routes.py", "schemas.py"],
      "core/": ["config.py", "database.py"]
    },
    "tests/": {
      "unit/": [],
      "integration/": []
    }
  },
  "data_models": [
    {
      "name": "User",
      "fields": [],
      "relationships": []
    }
  ],
  "api_spec": {
    "endpoints": [],
    "auth": "JWT"
  }
}
```

**工作流程** (参见 design_code_agent_detail.mermaid):
1. 架构模式选择（MVC/微服务/Pipeline等）
2. 系统分层设计
3. 模块职责定义
4. 接口规范设计
5. 数据模型设计
6. 技术选型细化
7. 目录结构规划
8. 生成设计文档

**关键特性**:
- 模块化设计
- 高内聚低耦合
- 可扩展性考量
- 最佳实践应用

### 3.4 Code Agent

**职责**: 代码生成与质量保证

**模型**: qwen-coder-plus

**核心功能**:
1. 基于设计生成代码
2. 生成单元测试
3. 代码静态分析
4. 自动调试和修复
5. 生成配置文件
6. 生成文档
7. 组织代码仓库

**输入**: Design Agent的设计文档

**输出**:
```json
{
  "repo_structure": {
    "README.md": "项目说明内容",
    "requirements.txt": "依赖列表",
    "src/main.py": "主程序代码",
    "src/models.py": "数据模型代码",
    "tests/test_main.py": "测试代码",
    ".gitignore": "Git配置",
    "Dockerfile": "容器配置"
  },
  "statistics": {
    "total_files": 15,
    "total_lines": 1500,
    "test_coverage": "85%"
  }
}
```

**生成顺序**:
1. 基础设施层（配置、工具）
2. 数据模型层（ORM、Schema）
3. 业务逻辑层（Services、Utils）
4. 接口层（Routes、Controllers）
5. 测试代码（单元测试、集成测试）
6. 项目文档（README、API文档）

**质量检查流程**:
1. 静态分析（语法、类型、风格）
2. 自动修复常见问题
3. 执行单元测试
4. 分析测试覆盖率
5. 迭代修复直到通过

**关键特性**:
- Repo级别生成
- 自我调试能力
- 测试驱动
- 文档完整性

---

## 4. MCP工具层

### 4.1 工具接口

MCP (Model Context Protocol) 提供标准化的工具接口：

```python
class MCPTools:
    def web_search(query: str) -> Dict
    def code_analysis(code: str) -> Dict
    def execute_code(code: str) -> Dict
    def read_document(path: str) -> Dict
```

### 4.2 工具详情

#### 4.2.1 Web Search Tool

**功能**: 实时网络搜索

**使用场景**:
- 查询最新技术栈信息
- 搜索最佳实践
- 查找解决方案
- 获取框架文档

**输入**:
```json
{
  "query": "FastAPI authentication best practices 2025"
}
```

**输出**:
```json
{
  "results": [
    {
      "title": "FastAPI Security",
      "url": "https://...",
      "snippet": "...",
      "relevance": 0.95
    }
  ]
}
```

#### 4.2.2 Code Analysis Tool

**功能**: 静态代码分析

**使用场景**:
- 语法检查
- 类型检查
- 代码风格检查
- 复杂度分析
- 安全漏洞检测

**输入**:
```json
{
  "code": "def function(): ...",
  "language": "python"
}
```

**输出**:
```json
{
  "issues": [
    {
      "type": "type_error",
      "line": 10,
      "message": "Missing type annotation",
      "severity": "warning"
    }
  ],
  "metrics": {
    "complexity": 5,
    "maintainability": 85
  }
}
```

#### 4.2.3 Code Execution Tool

**功能**: 沙箱代码执行

**使用场景**:
- 运行单元测试
- 验证代码正确性
- 调试问题

**安全措施**:
- 沙箱环境隔离
- 资源限制
- 超时控制

---

## 5. 通信协议

### 5.1 A2A消息格式

Agent间使用标准化的消息格式通信：

```python
@dataclass
class AgentMessage:
    msg_type: MessageType      # 消息类型
    sender: str                 # 发送方
    receiver: str               # 接收方
    content: Dict[str, Any]     # 消息内容
    metadata: Optional[Dict]    # 元数据
```

### 5.2 消息类型

```python
class MessageType(Enum):
    TASK_ASSIGNMENT = "task_assignment"
    RESEARCH_REQUEST = "research_request"
    RESEARCH_RESULT = "research_result"
    DESIGN_REQUEST = "design_request"
    DESIGN_RESULT = "design_result"
    CODE_REQUEST = "code_request"
    CODE_RESULT = "code_result"
    HUMAN_REVIEW = "human_review"
```

### 5.3 通信流程

完整的通信序列参见: `a2a_sequence.mermaid`

---

## 6. 前端设计

### 6.1 界面布局

参考 **Bolt.new** 的设计风格：

```
┌─────────────────────────────────────────────┐
│           Header (Logo + Title)              │
├──────────────────┬──────────────────────────┤
│                  │                          │
│   Left Panel     │      Right Panel         │
│   (Input Area)   │    (Output Area)         │
│                  │                          │
│  - 输入方式选择   │  - Agent状态显示          │
│  - 文本输入框    │  - 代码预览              │
│  - 文件上传      │  - 文件树               │
│  - 生成按钮      │  - 下载按钮              │
│  - Agent状态     │  - 统计信息              │
│                  │                          │
└──────────────────┴──────────────────────────┘
```

### 6.2 核心功能

1. **多格式输入**
   - 文本输入框
   - DOCX上传
   - PDF上传
   - Markdown上传
   - TXT上传

2. **实时状态展示**
   - Agent工作状态指示
   - 进度条显示
   - 日志输出

3. **代码预览**
   - 文件树导航
   - 代码语法高亮
   - 多文件Tab切换

4. **下载功能**
   - 一键下载ZIP
   - 单个文件下载

---

## 7. 数据流设计

### 7.1 完整数据流

```
用户输入
    ↓
文档解析 (DocumentParser)
    ↓
统一文本格式
    ↓
Orchestrator (任务规划)
    ↓
Research Agent (深度研究)
    ├── 需求分析
    ├── Web搜索
    └── 研究报告
    ↓
Design Agent (架构设计)
    ├── 模块设计
    ├── 接口设计
    └── 设计文档
    ↓
Code Agent (代码生成)
    ├── 代码生成
    ├── 质量检查
    ├── 自动修复
    └── 代码仓库
    ↓
Human Review (可选)
    ↓
最终输出 (ZIP下载)
```

### 7.2 状态管理

使用Streamlit的session_state管理状态：

```python
st.session_state = {
    'messages': [],              # 消息历史
    'generated_repo': {},        # 生成的代码
    'agent_status': {},          # Agent状态
    'current_phase': None        # 当前阶段
}
```

---

## 8. 部署架构

### 8.1 本地开发

```bash
# 安装依赖
pip install -r requirements.txt

# 设置环境变量
export DASHSCOPE_API_KEY="your-key"

# 启动Streamlit
streamlit run streamlit_app.py
```

### 8.2 Docker部署

```dockerfile
FROM python:3.9
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 8501
CMD ["streamlit", "run", "streamlit_app.py"]
```

### 8.3 生产环境

推荐配置：
- CPU: 4核
- 内存: 8GB
- 存储: 50GB
- 网络: 稳定的外网访问

---

## 9. 性能优化

### 9.1 缓存策略

1. **文档解析缓存**: 相同文档不重复解析
2. **LLM响应缓存**: 相似请求复用结果
3. **Web搜索缓存**: 缓存搜索结果

### 9.2 并发处理

1. 异步IO处理文档解析
2. 批量处理多个文件
3. 并行执行独立的MCP工具调用

### 9.3 流式输出

```python
for chunk in agent.call_llm(messages, stream=True):
    st.write(chunk)
```

实时展示LLM生成过程，提升用户体验。

---

## 10. 安全考虑

### 10.1 输入验证

- 文件大小限制（<50MB）
- 文件类型白名单
- 内容安全检查

### 10.2 代码执行安全

- 沙箱环境隔离
- 资源限制（CPU、内存、时间）
- 危险操作拦截

### 10.3 API安全

- API Key加密存储
- 请求频率限制
- 错误信息脱敏

---

## 11. 监控与日志

### 11.1 日志记录

```python
logging.info(f"[{agent_name}] Processing request")
logging.error(f"[{agent_name}] Error: {error}")
```

### 11.2 性能监控

- API调用延迟
- Token消耗统计
- 生成成功率
- 用户满意度

---

## 12. 扩展性设计

### 12.1 新增Agent

```python
class NewAgent(BaseAgent):
    def process(self, msg: AgentMessage):
        # 实现新的功能
        pass
```

### 12.2 新增MCP工具

```python
class MCPTools:
    @staticmethod
    def new_tool(params):
        # 实现新工具
        pass
```

### 12.3 支持新的输入格式

```python
class DocumentParser:
    @staticmethod
    def parse_excel(file_path):
        # 解析Excel
        pass
```

---

## 13. 测试策略

### 13.1 单元测试

- 测试各个Agent的独立功能
- 测试MCP工具接口
- 测试文档解析器

### 13.2 集成测试

- 测试完整的生成流程
- 测试Agent间通信
- 测试异常处理

### 13.3 端到端测试

- 模拟真实用户场景
- 验证生成的代码质量
- 性能压力测试

---

## 14. 附录

### 14.1 相关文档

- [系统架构流程图](agent_collaboration_flow.mermaid)
- [Research Agent详细流程](research_agent_detail.mermaid)
- [Design/Code Agent详细流程](design_code_agent_detail.mermaid)

### 14.2 外部依赖

- [ModelScope ms-agent](https://github.com/modelscope/ms-agent)
- [阿里云百炼平台](https://bailian.console.aliyun.com/)
- [Streamlit文档](https://docs.streamlit.io/)

---

**文档版本**: v1.0  
**最后更新**: 2025-11-08
