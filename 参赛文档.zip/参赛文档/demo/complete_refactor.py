#!/usr/bin/env python3
"""
完整的自动化重构脚本 - 将 backend_core.py 拆分到模块化结构
"""

import os
import re
from pathlib import Path

print("🚀 DeepCodeResearch 项目重构")
print("="*70)

# 读取原文件
with open('backend_core.py', 'r', encoding='utf-8') as f:
    content = f.read()
    lines = f.readlines()

# 重置文件指针并重新读取
with open('backend_core.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

def extract_section(start_marker, end_marker=None, next_section_marker=None):
    """提取指定标记之间的内容"""
    start_idx = None
    end_idx = None
    
    for i, line in enumerate(lines):
        if start_marker in line and start_idx is None:
            start_idx = i
        if end_marker and end_marker in line and start_idx is not None:
            end_idx = i
            break
        if next_section_marker and next_section_marker in line and start_idx is not None:
            end_idx = i
            break
    
    if start_idx is not None:
        if end_idx is None:
            end_idx = len(lines)
        return lines[start_idx:end_idx]
    return []

def write_file(filepath, imports, content_lines):
    """写入文件"""
    filepath = Path(filepath)
    
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(f'"""\n{filepath.stem.replace("_", " ").title()} 模块\n从 backend_core.py 重构而来\n"""\n\n')
        f.write(imports)
        f.write('\n')
        f.write(''.join(content_lines))
    
    print(f"✓ {filepath} ({len(content_lines)} 行)")

# ============================================================================
# 第1步: config 模块
# ============================================================================
print("\n[1/6] 拆分 config 模块...")

# settings.py
settings_imports = """import os
from typing import Optional
from pathlib import Path
"""

settings_content = extract_section("def load_api_key", next_section_marker="# ============================================================================\n# 配置")
write_file('src/config/settings.py', settings_imports, settings_content)

# agents.py
agents_imports = """import os
from dataclasses import dataclass
from .settings import load_api_key
"""

agents_content = extract_section("@dataclass\nclass AgentConfig", next_section_marker="# ============================================================================\n# 消息协议")
write_file('src/config/agents.py', agents_imports, agents_content)

# ============================================================================
# 第2步: core/messages 模块
# ============================================================================
print("\n[2/6] 拆分 core/messages 模块...")

messages_imports = """from enum import Enum
from dataclasses import dataclass
from typing import Dict, Any
"""

messages_content = extract_section("class MessageType(Enum)", next_section_marker="# ============================================================================\n# Base Agent")
write_file('src/core/messages.py', messages_imports, messages_content)

# ============================================================================
# 第3步: agents/base 模块
# ============================================================================
print("\n[3/6] 拆分 agents 模块...")

base_imports = """import time
from typing import Dict, List, Any
from openai import OpenAI

from ..config.agents import AgentConfig
from ..utils.logger import AgentLogger
from ..core.messages import AgentMessage
"""

base_content = extract_section("class BaseAgent:", next_section_marker="# Orchestrator Agent")
write_file('src/agents/base.py', base_imports, base_content)

# orchestrator.py
orch_imports = """from typing import Dict, Any

from .base import BaseAgent
from ..core.messages import AgentMessage, MessageType
"""

orch_content = extract_section("class OrchestratorAgent(BaseAgent):", next_section_marker="# Research Agent")
write_file('src/agents/orchestrator.py', orch_imports, orch_content)

# research.py
research_imports = """import json
from typing import Dict, Any

from .base import BaseAgent
from ..core.messages import AgentMessage, MessageType
"""

research_content = extract_section("class ResearchAgent(BaseAgent):", next_section_marker="# Design Agent")
write_file('src/agents/research.py', research_imports, research_content)

# design.py
design_imports = """import json
from typing import Dict, Any

from .base import BaseAgent
from ..core.messages import AgentMessage, MessageType
"""

design_content = extract_section("class DesignAgent(BaseAgent):", next_section_marker="# Code Agent")
write_file('src/agents/design.py', design_imports, design_content)

print("✓ agents 基础模块拆分完成")

# ============================================================================
# 第4步: 更新 __init__.py 文件
# ============================================================================
print("\n[4/6] 更新 __init__.py 文件...")

# src/utils/__init__.py
with open('src/utils/__init__.py', 'w') as f:
    f.write('"""工具模块"""\n\n')
    f.write('from .logger import AgentLogger\n')
    f.write('from .parser import DocumentParser\n')
    f.write('from .mcp_tools import MCPTools\n\n')
    f.write('__all__ = ["AgentLogger", "DocumentParser", "MCPTools"]\n')

# src/config/__init__.py
with open('src/config/__init__.py', 'w') as f:
    f.write('"""配置模块"""\n\n')
    f.write('from .settings import load_api_key\n')
    f.write('from .agents import AgentConfig, AGENTS_CONFIG\n\n')
    f.write('__all__ = ["load_api_key", "AgentConfig", "AGENTS_CONFIG"]\n')

# src/core/__init__.py
with open('src/core/__init__.py', 'w') as f:
    f.write('"""核心系统模块"""\n\n')
    f.write('from .messages import MessageType, AgentMessage\n\n')
    f.write('__all__ = ["MessageType", "AgentMessage"]\n')

# src/agents/__init__.py
with open('src/agents/__init__.py', 'w') as f:
    f.write('"""Agent 模块"""\n\n')
    f.write('from .base import BaseAgent\n')
    f.write('from .orchestrator import OrchestratorAgent\n')
    f.write('from .research import ResearchAgent\n')
    f.write('from .design import DesignAgent\n\n')
    f.write('__all__ = ["BaseAgent", "OrchestratorAgent", "ResearchAgent", "DesignAgent"]\n')

print("✓ __init__.py 文件更新完成")

# ============================================================================
# 第5步: 测试导入
# ============================================================================
print("\n[5/6] 测试模块导入...")

test_imports = [
    ("utils.logger", "AgentLogger"),
    ("utils.parser", "DocumentParser"),
    ("utils.mcp_tools", "MCPTools"),
    ("config.settings", "load_api_key"),
    ("config.agents", "AgentConfig"),
    ("core.messages", "MessageType"),
    ("agents.base", "BaseAgent"),
    ("agents.orchestrator", "OrchestratorAgent"),
    ("agents.research", "ResearchAgent"),
    ("agents.design", "DesignAgent"),
]

all_passed = True
for module_path, class_name in test_imports:
    try:
        exec(f"from src.{module_path} import {class_name}")
        print(f"  ✓ src.{module_path}.{class_name}")
    except Exception as e:
        print(f"  ✗ src.{module_path}.{class_name}: {e}")
        all_passed = False

# ============================================================================
# 第6步: 总结
# ============================================================================
print("\n[6/6] 重构总结")
print("="*70)

if all_passed:
    print("✅ 基础模块拆分完成!")
    print("\n已创建的模块:")
    print("  src/utils/logger.py")
    print("  src/utils/parser.py")
    print("  src/utils/mcp_tools.py")
    print("  src/config/settings.py")
    print("  src/config/agents.py")
    print("  src/core/messages.py")
    print("  src/agents/base.py")
    print("  src/agents/orchestrator.py")
    print("  src/agents/research.py")
    print("  src/agents/design.py")
    print("\n下一步:")
    print("  1. 拆分 Code Agent 和 templates 模块")
    print("  2. 拆分 DeepCodeResearchSystem")
    print("  3. 更新 streamlit_app.py")
else:
    print("⚠️  部分模块导入失败,请检查错误信息")

