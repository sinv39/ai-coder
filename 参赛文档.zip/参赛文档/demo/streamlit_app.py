"""
DeepCodeResearch - Streamlit Frontend
参考 Bolt.new 的界面设计
"""

import streamlit as st
import os
import json
import zipfile
from io import BytesIO
from datetime import datetime
from pathlib import Path
import docx
import PyPDF2
import markdown

# 页面配置
st.set_page_config(
    page_title="DeepCodeResearch",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 自定义CSS样式 - 参考Bolt.new的风格
st.markdown("""
<style>
    /* 主容器样式 */
    .main {
        background-color: #0f1419;
    }
    
    /* 标题样式 */
    h1 {
        color: #ffffff;
        font-weight: 700;
        font-size: 2.5rem;
        margin-bottom: 1rem;
    }
    
    /* 卡片样式 */
    .stCard {
        background-color: #1a1f2e;
        border-radius: 12px;
        padding: 1.5rem;
        border: 1px solid #2d3748;
    }
    
    /* 按钮样式 */
    .stButton > button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 0.75rem 2rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 16px rgba(102, 126, 234, 0.4);
    }
    
    /* 进度条样式 */
    .stProgress > div > div {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
    }
    
    /* 代码块样式 */
    .stCodeBlock {
        background-color: #1e1e1e;
        border-radius: 8px;
        border: 1px solid #2d3748;
    }
    
    /* 侧边栏样式 */
    .css-1d391kg {
        background-color: #161b22;
    }
    
    /* 文件上传区域样式 */
    .uploadedFile {
        background-color: #1a1f2e;
        border-radius: 8px;
        padding: 1rem;
        border: 1px solid #2d3748;
    }
    
    /* Agent状态指示器 */
    .agent-status {
        display: inline-block;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        margin-right: 8px;
    }
    
    .agent-active {
        background-color: #10b981;
        animation: pulse 2s infinite;
    }
    
    .agent-waiting {
        background-color: #fbbf24;
    }
    
    .agent-completed {
        background-color: #3b82f6;
    }
    
    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.5; }
    }
    
    /* 两栏布局样式 */
    .split-view {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1rem;
        height: 100%;
    }
</style>
""", unsafe_allow_html=True)

# 初始化session state
if 'messages' not in st.session_state:
    st.session_state.messages = []
if 'generated_repo' not in st.session_state:
    st.session_state.generated_repo = None
if 'agent_status' not in st.session_state:
    st.session_state.agent_status = {
        'orchestrator': 'waiting',
        'research': 'waiting',
        'design': 'waiting',
        'code': 'waiting'
    }
if 'current_phase' not in st.session_state:
    st.session_state.current_phase = None


def parse_docx(file):
    """解析DOCX文件"""
    doc = docx.Document(file)
    return '\n'.join([paragraph.text for paragraph in doc.paragraphs])


def parse_pdf(file):
    """解析PDF文件"""
    pdf_reader = PyPDF2.PdfReader(file)
    text = []
    for page in pdf_reader.pages:
        text.append(page.extract_text())
    return '\n'.join(text)


def parse_markdown(file):
    """解析Markdown文件"""
    content = file.read().decode('utf-8')
    return content


def process_uploaded_file(uploaded_file):
    """处理上传的文件"""
    file_type = uploaded_file.name.split('.')[-1].lower()
    
    try:
        if file_type == 'docx':
            return parse_docx(uploaded_file)
        elif file_type == 'pdf':
            return parse_pdf(uploaded_file)
        elif file_type in ['md', 'markdown']:
            return parse_markdown(uploaded_file)
        elif file_type == 'txt':
            return uploaded_file.read().decode('utf-8')
        else:
            st.error(f"不支持的文件格式: {file_type}")
            return None
    except Exception as e:
        st.error(f"文件解析错误: {str(e)}")
        return None


def update_agent_status(agent, status):
    """更新Agent状态"""
    st.session_state.agent_status[agent] = status


def render_agent_status():
    """渲染Agent状态面板"""
    st.markdown("### 🤖 Agent 协作状态")
    
    agents = {
        'orchestrator': '📋 Orchestrator (任务编排)',
        'research': '🔍 Research (深度研究)',
        'design': '🎨 Design (架构设计)',
        'code': '💻 Code (代码生成)'
    }
    
    for agent_id, agent_name in agents.items():
        status = st.session_state.agent_status[agent_id]
        
        if status == 'active':
            status_html = f'<span class="agent-status agent-active"></span>'
            status_text = "🔄 工作中"
        elif status == 'completed':
            status_html = f'<span class="agent-status agent-completed"></span>'
            status_text = "✅ 完成"
        else:
            status_html = f'<span class="agent-status agent-waiting"></span>'
            status_text = "⏸️ 等待"
        
        st.markdown(f"{status_html} **{agent_name}**: {status_text}", unsafe_allow_html=True)


def create_repo_zip(repo_structure):
    """创建代码仓库的ZIP文件"""
    zip_buffer = BytesIO()
    
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        for file_path, content in repo_structure.items():
            zip_file.writestr(file_path, content)
    
    zip_buffer.seek(0)
    return zip_buffer


def render_code_preview(repo_structure):
    """渲染代码预览"""
    st.markdown("### 📁 生成的代码仓库")
    
    # 创建文件树
    st.markdown("#### 文件结构")
    file_tree = sorted(repo_structure.keys())
    
    # 使用expander显示文件树
    with st.expander("📂 查看文件树", expanded=True):
        for file_path in file_tree:
            indent = "　" * file_path.count('/')
            file_name = file_path.split('/')[-1]
            
            # 根据文件类型选择图标
            if file_name.endswith('.py'):
                icon = "🐍"
            elif file_name.endswith('.md'):
                icon = "📝"
            elif file_name.endswith('.txt'):
                icon = "📄"
            elif file_name.endswith('.json'):
                icon = "📋"
            elif file_name == 'Dockerfile':
                icon = "🐳"
            else:
                icon = "📄"
            
            st.markdown(f"{indent}{icon} `{file_name}`")
    
    # 代码预览 - 使用tabs显示不同文件
    st.markdown("#### 代码预览")
    
    # 选择要预览的文件
    preview_files = [f for f in file_tree if f.endswith(('.py', '.md', '.txt', '.json'))]
    
    if preview_files:
        selected_file = st.selectbox("选择文件预览", preview_files)
        
        if selected_file:
            content = repo_structure[selected_file]
            
            # 根据文件类型选择语法高亮
            if selected_file.endswith('.py'):
                language = 'python'
            elif selected_file.endswith('.json'):
                language = 'json'
            elif selected_file.endswith('.md'):
                language = 'markdown'
            else:
                language = 'text'
            
            st.code(content, language=language, line_numbers=True)


# 主界面
def main():
    # Header
    col1, col2 = st.columns([3, 1])
    with col1:
        st.title("🚀 DeepCodeResearch")
        st.markdown("**Research First, Then Code** - 研究驱动的智能代码生成系统")
    
    with col2:
        st.markdown("""
        <div style='text-align: right; padding-top: 20px;'>
            <span style='color: #667eea; font-weight: 600;'>Powered by</span><br/>
            <span style='color: #764ba2;'>ms-agent + 百炼</span>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    # 两栏布局 - 参考Bolt.new
    left_col, right_col = st.columns([1, 1])
    
    # 左侧 - 输入区域
    with left_col:
        st.markdown("### 📝 输入需求")
        
        # 输入方式选择
        input_method = st.radio(
            "选择输入方式",
            ["文本输入", "上传文档"],
            horizontal=True
        )
        
        input_content = None
        
        if input_method == "文本输入":
            input_content = st.text_area(
                "描述你的项目需求",
                height=300,
                placeholder="例如：\n\n创建一个任务管理Web应用：\n- 用户可以创建、编辑、删除任务\n- 支持任务分类和标签\n- 使用Python FastAPI后端\n- React前端\n- PostgreSQL数据库\n- JWT认证\n- 完整的单元测试"
            )
        else:
            uploaded_file = st.file_uploader(
                "上传需求文档",
                type=['docx', 'pdf', 'md', 'txt'],
                help="支持 DOCX、PDF、Markdown、TXT 格式"
            )
            
            if uploaded_file:
                with st.spinner("解析文档中..."):
                    input_content = process_uploaded_file(uploaded_file)
                    
                if input_content:
                    st.success(f"✅ 文档解析成功! 共 {len(input_content)} 字符")
                    
                    # 显示文档预览
                    with st.expander("📄 文档内容预览"):
                        st.text_area("", input_content, height=200, disabled=True)
        
        # 生成按钮
        st.markdown("---")
        
        generate_col1, generate_col2 = st.columns([3, 1])
        
        with generate_col1:
            generate_button = st.button(
                "🚀 开始生成代码",
                use_container_width=True,
                disabled=not input_content
            )
        
        with generate_col2:
            if st.button("🔄", help="重置"):
                st.session_state.clear()
                st.rerun()
        
        # Agent状态显示
        if st.session_state.current_phase:
            st.markdown("---")
            render_agent_status()
        
        # 处理生成请求
        if generate_button and input_content:
            # 检查 API Key
            api_key = os.getenv("DASHSCOPE_API_KEY")
            if not api_key:
                st.error("❌ 未配置 DASHSCOPE_API_KEY 环境变量！")
                st.info("""
                **配置步骤：**
                1. 访问 [阿里云百炼控制台](https://bailian.console.aliyun.com/)
                2. 获取 API Key
                3. 设置环境变量：
                ```bash
                export DASHSCOPE_API_KEY="your-api-key"
                ```
                4. 重启 Streamlit 应用
                """)
            else:
                st.session_state.current_phase = "processing"

                # 导入后端系统
                from backend_core import DeepCodeResearchSystem

                # 定义状态回调函数
                def status_callback(agent_name: str, status: str):
                    """更新Agent状态"""
                    agent_map = {
                        'Orchestrator': 'orchestrator',
                        'Research': 'research',
                        'Design': 'design',
                        'Code': 'code'
                    }
                    agent_id = agent_map.get(agent_name, agent_name.lower())
                    update_agent_status(agent_id, status)

                try:
                    # 初始化系统
                    with st.spinner("🚀 初始化 Agent 系统..."):
                        system = DeepCodeResearchSystem()

                    # 创建进度容器
                    progress_container = st.empty()

                    with progress_container.container():
                        st.info("🔄 代码生成进行中，请稍候...")

                        # 显示当前Agent状态
                        status_placeholder = st.empty()

                        # 调用后端生成代码
                        result = system.generate(
                            user_input=input_content,
                            input_type="text",
                            callback=status_callback
                        )

                        # 保存生成的代码仓库
                        if result and 'code_repo' in result:
                            st.session_state.generated_repo = result['code_repo']
                            st.success("✅ 代码生成完成!")
                        else:
                            st.error("❌ 代码生成失败，请查看错误信息")

                except Exception as e:
                    st.error(f"❌ 生成过程出错: {str(e)}")
                    import traceback
                    with st.expander("查看详细错误信息"):
                        st.code(traceback.format_exc())
                finally:
                    # 标记所有Agent为完成状态
                    for agent in ['orchestrator', 'research', 'design', 'code']:
                        if st.session_state.agent_status[agent] == 'active':
                            update_agent_status(agent, 'completed')
    
    # 右侧 - 输出区域
    with right_col:
        st.markdown("### 📦 生成结果")
        
        if st.session_state.generated_repo:
            # 渲染代码预览
            render_code_preview(st.session_state.generated_repo)
            
            # 下载按钮
            st.markdown("---")
            st.markdown("#### 📥 下载代码")
            
            zip_buffer = create_repo_zip(st.session_state.generated_repo)
            
            st.download_button(
                label="⬇️ 下载完整代码仓库 (ZIP)",
                data=zip_buffer,
                file_name=f"generated_repo_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip",
                mime="application/zip",
                use_container_width=True
            )
            
            # 统计信息
            st.markdown("---")
            st.markdown("#### 📊 统计信息")
            
            total_files = len(st.session_state.generated_repo)
            total_lines = sum(len(content.split('\n')) for content in st.session_state.generated_repo.values())
            
            metric_col1, metric_col2 = st.columns(2)
            with metric_col1:
                st.metric("文件数量", total_files)
            with metric_col2:
                st.metric("代码行数", total_lines)
        
        else:
            # 空状态显示
            st.info("""
            👈 请在左侧输入你的项目需求
            
            **支持的输入方式：**
            - ✍️ 直接文本输入
            - 📄 上传 DOCX 文档
            - 📑 上传 PDF 文档
            - 📝 上传 Markdown 文件
            - 📃 上传 TXT 文本
            
            **生成内容：**
            - ✅ 完整的源代码
            - ✅ 单元测试
            - ✅ 配置文件
            - ✅ README 文档
            - ✅ requirements.txt
            - ✅ Docker 配置
            """)
            
            # 显示示例
            with st.expander("💡 查看示例需求"):
                st.markdown("""
                **示例1: Web应用**
                ```
                创建一个博客系统：
                - 用户注册和登录
                - 发布和编辑文章
                - 评论功能
                - 标签和分类
                - 使用 FastAPI + React
                - PostgreSQL 数据库
                ```
                
                **示例2: 数据处理**
                ```
                创建数据分析工具：
                - 读取 CSV 文件
                - 数据清洗和转换
                - 统计分析
                - 可视化图表
                - 生成 HTML 报告
                ```
                
                **示例3: API服务**
                ```
                创建 RESTful API：
                - 用户管理 CRUD
                - JWT 认证
                - API 文档 (Swagger)
                - 限流和缓存
                - Docker 容器化
                ```
                """)

    # Sidebar - 系统信息
    with st.sidebar:
        st.markdown("## ⚙️ 系统设置")
        
        st.markdown("### 🤖 模型配置")
        st.info("""
        **Orchestrator**: qwen-max  
        **Research**: qwen-long (1000万token)  
        **Design**: qwen-max  
        **Code**: qwen-coder-plus
        """)
        
        st.markdown("---")
        
        st.markdown("### 📚 文档")
        st.markdown("""
        - [系统架构](/)
        - [Agent协作流程](/)
        - [使用指南](/)
        """)
        
        st.markdown("---")
        
        st.markdown("### 🔗 相关链接")
        st.markdown("""
        - [ms-agent框架](https://github.com/modelscope/ms-agent)
        - [百炼平台](https://bailian.console.aliyun.com/)
        """)


if __name__ == "__main__":
    main()
