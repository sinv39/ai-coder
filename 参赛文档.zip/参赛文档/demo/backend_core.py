"""
DeepCodeResearch Backend - Core Implementation
基于 ms-agent 框架和阿里云百炼平台
"""

import os
import json
import logging
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum
from datetime import datetime
from openai import OpenAI
import docx
import PyPDF2
import markdown
from pathlib import Path


# ============================================================================
# 日志系统
# ============================================================================

class AgentLogger:
    """Agent 专用结构化日志记录器"""

    def __init__(self, agent_name: str, log_level=logging.INFO):
        self.agent_name = agent_name
        self.logger = logging.getLogger(f"Agent.{agent_name}")
        self.logger.setLevel(log_level)

        # 避免重复添加 handler
        if not self.logger.handlers:
            # 控制台 handler - 彩色输出
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(
                logging.Formatter(
                    '[%(asctime)s] [%(name)s] %(levelname)s - %(message)s',
                    datefmt='%H:%M:%S'
                )
            )
            self.logger.addHandler(console_handler)

            # 创建 logs 目录
            Path('logs').mkdir(exist_ok=True)

            # 文件 handler - 详细日志
            file_handler = logging.FileHandler(
                f'logs/agent_{agent_name.lower()}_{datetime.now():%Y%m%d}.log',
                encoding='utf-8'
            )
            file_handler.setFormatter(
                logging.Formatter(
                    '[%(asctime)s] %(levelname)s - %(message)s'
                )
            )
            self.logger.addHandler(file_handler)

    def info(self, message: str):
        """记录信息"""
        self.logger.info(message)

    def debug(self, message: str):
        """记录调试信息"""
        self.logger.debug(message)

    def warning(self, message: str):
        """记录警告"""
        self.logger.warning(message)

    def error(self, message: str):
        """记录错误"""
        self.logger.error(message)

    def log_llm_call(self, prompt: str, response: str, duration: float, model: str):
        """记录 LLM 调用详情"""
        self.logger.info(f"LLM 调用完成 (模型: {model}, 耗时: {duration:.2f}s)")
        self.logger.debug(f"Prompt 长度: {len(prompt)} 字符")
        self.logger.debug(f"Response 长度: {len(response)} 字符")

        # 保存完整 prompt 和 response 到独立文件
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

        prompt_file = f'logs/{self.agent_name}_prompt_{timestamp}.txt'
        with open(prompt_file, 'w', encoding='utf-8') as f:
            f.write(f"=== LLM Prompt ===\n")
            f.write(f"Agent: {self.agent_name}\n")
            f.write(f"Model: {model}\n")
            f.write(f"Time: {datetime.now()}\n")
            f.write(f"Length: {len(prompt)} chars\n")
            f.write(f"\n{'='*70}\n\n")
            f.write(prompt)

        response_file = f'logs/{self.agent_name}_response_{timestamp}.txt'
        with open(response_file, 'w', encoding='utf-8') as f:
            f.write(f"=== LLM Response ===\n")
            f.write(f"Agent: {self.agent_name}\n")
            f.write(f"Model: {model}\n")
            f.write(f"Time: {datetime.now()}\n")
            f.write(f"Length: {len(response)} chars\n")
            f.write(f"Duration: {duration:.2f}s\n")
            f.write(f"\n{'='*70}\n\n")
            f.write(response)

        self.logger.debug(f"完整 prompt 保存到: {prompt_file}")
        self.logger.debug(f"完整 response 保存到: {response_file}")

    def log_message(self, msg, direction: str):
        """记录 Agent 消息传递"""
        self.logger.info(
            f"{direction} {msg.msg_type.value}: "
            f"{msg.sender} → {msg.receiver}"
        )

    def log_fallback(self, reason: str):
        """记录 fallback 使用"""
        self.logger.warning(f"⚠️  使用 fallback 生成器: {reason}")


# ============================================================================
# 配置加载
# ============================================================================

def load_api_key() -> Optional[str]:
    """
    加载 API Key,优先级:
    1. 环境变量 DASHSCOPE_API_KEY
    2. .env 文件
    3. 项目根目录的 .env 文件
    """
    # 1. 尝试从环境变量获取
    api_key = os.getenv("DASHSCOPE_API_KEY")
    if api_key:
        print(f"✓ 从环境变量加载 API Key")
        return api_key

    # 2. 尝试从当前目录的 .env 文件加载
    env_files = [
        Path.cwd() / '.env',  # 当前工作目录
        Path(__file__).parent / '.env',  # backend_core.py 所在目录
        Path(__file__).parent.parent / '.env',  # 项目根目录
    ]

    for env_file in env_files:
        if env_file.exists():
            try:
                with open(env_file, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        # 跳过注释和空行
                        if not line or line.startswith('#'):
                            continue
                        # 解析 KEY=VALUE 格式
                        if '=' in line:
                            key, value = line.split('=', 1)
                            key = key.strip()
                            value = value.strip().strip('"').strip("'")  # 移除引号
                            if key == 'DASHSCOPE_API_KEY' and value:
                                print(f"✓ 从 {env_file} 加载 API Key")
                                return value
            except Exception as e:
                print(f"警告: 读取 {env_file} 失败: {e}")
                continue

    # 3. 都没有找到
    print("❌ 未找到 DASHSCOPE_API_KEY")
    print("请配置 API Key:")
    print("  方法1: 设置环境变量 export DASHSCOPE_API_KEY='your-key'")
    print("  方法2: 在项目根目录创建 .env 文件,内容: DASHSCOPE_API_KEY=your-key")
    return None


# ============================================================================
# 配置
# ============================================================================

@dataclass
class AgentConfig:
    """Agent配置"""
    name: str
    model: str
    api_key: str
    base_url: str = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    max_tokens: int = 4096
    temperature: float = 0.7


# 加载 API Key
_API_KEY = load_api_key()

# Agent配置
AGENTS_CONFIG = {
    'orchestrator': AgentConfig(
        name="Orchestrator",
        model="qwen-max",
        api_key=_API_KEY,
        max_tokens=4096,
        temperature=0.7
    ),
    'research': AgentConfig(
        name="Research",
        model="qwen-long",
        api_key=_API_KEY,
        max_tokens=8192,  # API 限制最大 8192
        temperature=0.3
    ),
    'design': AgentConfig(
        name="Design",
        model="qwen-max",
        api_key=_API_KEY,
        max_tokens=8192,
        temperature=0.5
    ),
    'code': AgentConfig(
        name="Code",
        model="qwen-coder-plus",
        api_key=_API_KEY,
        max_tokens=8192,
        temperature=0.2
    )
}


# ============================================================================
# 消息协议
# ============================================================================

class MessageType(Enum):
    """Agent间消息类型"""
    TASK_ASSIGNMENT = "task_assignment"
    RESEARCH_REQUEST = "research_request"
    RESEARCH_RESULT = "research_result"
    DESIGN_REQUEST = "design_request"
    DESIGN_RESULT = "design_result"
    CODE_REQUEST = "code_request"
    CODE_RESULT = "code_result"


@dataclass
class AgentMessage:
    """Agent通信消息"""
    msg_type: MessageType
    sender: str
    receiver: str
    content: Dict[str, Any]
    
    def to_dict(self) -> Dict:
        data = asdict(self)
        data['msg_type'] = self.msg_type.value
        return data


# ============================================================================
# 文档解析器
# ============================================================================

class DocumentParser:
    """统一的文档解析接口"""
    
    @staticmethod
    def parse_docx(file_path: str) -> str:
        """解析DOCX文件"""
        doc = docx.Document(file_path)
        return '\n'.join([para.text for para in doc.paragraphs])
    
    @staticmethod
    def parse_pdf(file_path: str) -> str:
        """解析PDF文件"""
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            text = []
            for page in pdf_reader.pages:
                text.append(page.extract_text())
            return '\n'.join(text)
    
    @staticmethod
    def parse_markdown(file_path: str) -> str:
        """解析Markdown文件"""
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    
    @staticmethod
    def parse_text(file_path: str) -> str:
        """解析文本文件"""
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read()
    
    @classmethod
    def parse(cls, file_path: str) -> str:
        """根据文件类型自动选择解析器"""
        ext = file_path.split('.')[-1].lower()
        
        if ext == 'docx':
            return cls.parse_docx(file_path)
        elif ext == 'pdf':
            return cls.parse_pdf(file_path)
        elif ext in ['md', 'markdown']:
            return cls.parse_markdown(file_path)
        elif ext == 'txt':
            return cls.parse_text(file_path)
        else:
            raise ValueError(f"不支持的文件格式: {ext}")


# ============================================================================
# MCP工具接口
# ============================================================================

class MCPTools:
    """Model Context Protocol 工具集"""
    
    @staticmethod
    def web_search(query: str) -> Dict[str, Any]:
        """网络搜索工具"""
        # 实际实现中应调用真实的搜索API
        return {
            "tool": "web_search",
            "query": query,
            "results": []
        }
    
    @staticmethod
    def code_analysis(code: str, language: str = "python") -> Dict[str, Any]:
        """代码静态分析"""
        # 实际实现中应使用AST分析、pylint等工具
        return {
            "tool": "code_analysis",
            "language": language,
            "issues": [],
            "suggestions": []
        }
    
    @staticmethod
    def execute_code(code: str, language: str = "python") -> Dict[str, Any]:
        """代码执行测试"""
        # 实际实现中应在沙箱环境中执行
        return {
            "tool": "execute_code",
            "language": language,
            "status": "success",
            "output": ""
        }


# ============================================================================
# Base Agent
# ============================================================================


# ============================================================================
# Agent 模块导入
# ============================================================================

from src.agents import (
    BaseAgent,
    OrchestratorAgent,
    ResearchAgent,
    DesignAgent,
    CodeAgent
)


# ============================================================================
# 主系统
# ============================================================================

class DeepCodeResearchSystem:
    """完整的代码生成系统"""

    def __init__(self):
        self.orchestrator = OrchestratorAgent(AGENTS_CONFIG['orchestrator'])
        self.research = ResearchAgent(AGENTS_CONFIG['research'])
        self.design = DesignAgent(AGENTS_CONFIG['design'])
        self.code = CodeAgent(AGENTS_CONFIG['code'])

        # 系统日志
        self.logger = logging.getLogger("System")
        self.logger.setLevel(logging.INFO)

        if not self.logger.handlers:
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(
                logging.Formatter(
                    '[%(asctime)s] [%(name)s] %(message)s',
                    datefmt='%H:%M:%S'
                )
            )
            self.logger.addHandler(console_handler)

            Path('logs').mkdir(exist_ok=True)
            file_handler = logging.FileHandler(
                f'logs/system_{datetime.now():%Y%m%d}.log',
                encoding='utf-8'
            )
            file_handler.setFormatter(
                logging.Formatter('[%(asctime)s] %(message)s')
            )
            self.logger.addHandler(file_handler)

    def generate(self, user_input: str,
                 input_type: str = "text",
                 callback: Optional[callable] = None) -> Dict[str, Any]:
        """
        生成代码仓库

        Args:
            user_input: 用户输入（文本或文件路径）
            input_type: 输入类型 (text/file)
            callback: 状态回调函数

        Returns:
            包含生成的代码仓库的字典
        """

        start_time = time.time()

        self.logger.info("="*70)
        self.logger.info("🚀 DeepCodeResearch 代码生成系统启动")
        self.logger.info("="*70)

        # 1. 解析输入
        self.logger.info("\n[输入解析]")
        if input_type == "file":
            self.logger.info(f"解析文档: {user_input}")
            requirement = DocumentParser.parse(user_input)
        else:
            requirement = user_input

        self.logger.info(f"需求长度: {len(requirement)} 字符")
        self.logger.info(f"需求摘要: {requirement[:100]}...")

        # 2. 任务规划
        if callback:
            callback("orchestrator", "active")

        self.logger.info("\n" + "="*70)
        self.logger.info("[Phase 1/4] Orchestrator - 任务规划")
        self.logger.info("="*70)
        phase_start = time.time()

        task_plan = self.orchestrator.process(requirement)

        phase_duration = time.time() - phase_start
        self.logger.info(f"✓ Orchestrator 完成,耗时 {phase_duration:.2f}s")

        if callback:
            callback("orchestrator", "completed")
            callback("research", "active")

        # 3. 深度研究
        self.logger.info("\n" + "="*70)
        self.logger.info("[Phase 2/4] Research - 深度需求分析 (qwen-long)")
        self.logger.info("="*70)
        phase_start = time.time()

        research_msg = AgentMessage(
            msg_type=MessageType.RESEARCH_REQUEST,
            sender="Orchestrator",
            receiver="Research",
            content={"requirement": requirement}
        )
        research_result = self.research.receive_message(research_msg)

        phase_duration = time.time() - phase_start
        self.logger.info(f"✓ Research 完成,耗时 {phase_duration:.2f}s")
        self.logger.info(f"项目类型: {research_result.get('project_type', 'N/A')}")
        self.logger.info(f"项目名称: {research_result.get('project_name', 'N/A')}")

        if callback:
            callback("research", "completed")
            callback("design", "active")

        # 4. 架构设计
        self.logger.info("\n" + "="*70)
        self.logger.info("[Phase 3/4] Design - 系统架构设计 (qwen-max)")
        self.logger.info("="*70)
        phase_start = time.time()

        design_msg = AgentMessage(
            msg_type=MessageType.DESIGN_REQUEST,
            sender="Orchestrator",
            receiver="Design",
            content={"research_result": research_result}
        )
        design_result = self.design.receive_message(design_msg)

        phase_duration = time.time() - phase_start
        self.logger.info(f"✓ Design 完成,耗时 {phase_duration:.2f}s")
        self.logger.info(f"模块数量: {len(design_result.get('modules', []))}")

        if callback:
            callback("design", "completed")
            callback("code", "active")

        # 5. 代码生成
        self.logger.info("\n" + "="*70)
        self.logger.info("[Phase 4/4] Code - 代码生成 (qwen-coder-plus)")
        self.logger.info("="*70)
        phase_start = time.time()

        code_msg = AgentMessage(
            msg_type=MessageType.CODE_REQUEST,
            sender="Orchestrator",
            receiver="Code",
            content={"design_result": design_result}
        )
        code_repo = self.code.receive_message(code_msg)

        phase_duration = time.time() - phase_start
        self.logger.info(f"✓ Code 完成,耗时 {phase_duration:.2f}s")

        if callback:
            callback("code", "completed")

        # 6. 统计和总结
        total_time = time.time() - start_time
        total_lines = sum(len(content.split('\n')) for content in code_repo.values())

        self.logger.info("\n" + "="*70)
        self.logger.info("✅ 代码生成完成!")
        self.logger.info("="*70)
        self.logger.info(f"总耗时: {total_time:.2f}s")
        self.logger.info(f"生成文件数: {len(code_repo)} 个")
        self.logger.info(f"代码总行数: {total_lines} 行")
        self.logger.info(f"文件列表:")
        for file_path in sorted(code_repo.keys()):
            lines = len(code_repo[file_path].split('\n'))
            self.logger.info(f"  - {file_path} ({lines} 行)")
        self.logger.info("="*70)

        # 7. 返回完整结果
        return {
            "status": "success",
            "task_plan": task_plan,
            "research": research_result,
            "design": design_result,
            "code_repo": code_repo,
            "metadata": {
                "total_time": total_time,
                "file_count": len(code_repo),
                "total_lines": total_lines
            }
        }


# ============================================================================
# 使用示例
# ============================================================================

def main():
    """主函数"""
    system = DeepCodeResearchSystem()
    
    # 示例：文本输入
    requirement = """
    创建一个任务管理Web应用：
    - 用户可以创建、编辑、删除任务
    - 支持任务分类和标签
    - 使用Python FastAPI后端
    - React前端
    - PostgreSQL数据库
    - JWT认证
    """
    
    result = system.generate(requirement, input_type="text")
    
    print("\n生成的代码仓库:")
    for file_path in result['code_repo'].keys():
        print(f"  - {file_path}")


if __name__ == "__main__":
    main()
