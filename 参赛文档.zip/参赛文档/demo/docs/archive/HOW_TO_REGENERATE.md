# 如何重新生成代码(修复 pygame 依赖问题)

## 问题说明

如果你下载的代码包含以下 `requirements.txt`:

```txt
pygame==2.1.2  # ❌ 旧版本,需要 SDL2 库
```

并且安装时报错:
```
/bin/sh: sdl2-config: command not found
ERROR: Failed to build 'pygame'
```

这是因为你下载的是**修复之前**生成的代码。

## ✅ 解决方案

当前系统已经修复,现在生成的代码使用 **tkinter**(Python 标准库),不再需要 pygame!

### 方法1: 重新生成代码(推荐)

```bash
# 1. 确保在项目根目录
cd /Users/jin/AI-Com/DeepCodeResearch

# 2. 启动 Streamlit 应用
streamlit run streamlit_app.py

# 3. 在浏览器中重新生成
# - 输入: "写一个贪吃蛇游戏"
# - 点击: "开始生成代码"
# - 下载新的 ZIP 文件

# 4. 解压新文件并运行
cd generated_repo_new
python src/main.py  # 直接运行,无需 pip install!
```

### 方法2: 验证当前系统

```bash
# 测试当前系统生成的代码
source .venv/bin/activate

python -c "
from backend_core import DeepCodeResearchSystem

system = DeepCodeResearchSystem()
result = system.generate('写一个贪吃蛇游戏', input_type='text')

repo = result['code_repo']
requirements = repo.get('requirements.txt', '')

print('=== requirements.txt ===')
print(requirements)
print()

if 'pygame' in requirements.lower():
    print('❌ 仍在使用 pygame')
elif 'tkinter' in repo.get('src/main.py', ''):
    print('✅ 已改用 tkinter (无需外部依赖)')
"
```

**预期输出**:
```
✓ 从 .env 加载 API Key
=== requirements.txt ===
# 本项目仅使用 Python 标准库,无需安装任何额外依赖
# tkinter 是 Python 自带的 GUI 库,已随 Python 一起安装

✅ 已改用 tkinter (无需外部依赖)
```

## 新版本 vs 旧版本对比

### ❌ 旧版本(修复前)

**requirements.txt**:
```txt
pygame==2.1.2
```

**安装**:
```bash
pip install -r requirements.txt  # ❌ 失败!需要 SDL2
```

**错误**:
```
/bin/sh: sdl2-config: command not found
ERROR: Failed to build 'pygame'
```

### ✅ 新版本(修复后)

**requirements.txt**:
```txt
# 本项目仅使用 Python 标准库,无需安装任何额外依赖
# tkinter 是 Python 自带的 GUI 库,已随 Python 一起安装
```

**运行**:
```bash
python src/main.py  # ✅ 直接运行!
```

**无需安装任何依赖!**

## 新版本代码特点

### 使用 tkinter 实现

**src/main.py**:
```python
#!/usr/bin/env python3
import tkinter as tk  # Python 标准库!
from game import SnakeGame

def main():
    root = tk.Tk()
    root.title("贪吃蛇游戏")

    game = SnakeGame(root)
    game.start()

    root.mainloop()

if __name__ == "__main__":
    main()
```

### 完整功能

- ✅ 使用 Python 标准库 tkinter
- ✅ 完整的游戏逻辑(300+ 行)
- ✅ 方向键控制
- ✅ 碰撞检测
- ✅ 分数统计
- ✅ Game Over 和重启
- ✅ 零外部依赖

## 如何确认是新版本

检查生成的 `requirements.txt` 文件:

```bash
cat requirements.txt
```

**如果看到**:
```txt
# 本项目仅使用 Python 标准库,无需安装任何额外依赖
# tkinter 是 Python 自带的 GUI 库,已随 Python 一起安装
```

✅ **这是新版本,可以直接运行!**

**如果看到**:
```txt
pygame==2.1.2
```

❌ **这是旧版本,请重新生成!**

## 完整的重新生成步骤

```bash
# 1. 进入项目目录
cd /Users/jin/AI-Com/DeepCodeResearch

# 2. 确保 .env 文件已配置
cat .env
# 应该看到: DASHSCOPE_API_KEY=sk-xxxxx

# 3. 激活虚拟环境
source .venv/bin/activate

# 4. 启动 Streamlit
streamlit run streamlit_app.py

# 5. 在浏览器 http://localhost:8501 中:
#    - 左侧输入: "写一个贪吃蛇游戏"
#    - 点击: "🚀 开始生成代码"
#    - 等待生成完成(可能需要1-2分钟)
#    - 右侧点击: "⬇️ 下载完整代码仓库 (ZIP)"

# 6. 解压下载的 ZIP 文件
cd ~/Downloads
unzip generated_repo_*.zip
cd generated_repo_*/

# 7. 直接运行!
python src/main.py
```

## 验证生成的代码

```bash
# 1. 检查文件结构
tree -L 2

# 预期输出:
# .
# ├── README.md
# ├── requirements.txt
# ├── src
# │   ├── __init__.py
# │   ├── main.py
# │   ├── game.py
# │   └── config.py
# └── tests
#     ├── __init__.py
#     └── test_game.py

# 2. 检查是否使用 tkinter
grep -i "import tkinter" src/main.py

# 预期输出:
# import tkinter as tk  # ✅ 使用标准库

# 3. 检查是否还有 pygame
grep -i "pygame" -r .

# 预期输出:
# (空,没有 pygame) # ✅ 已移除

# 4. 运行游戏
python src/main.py
```

## 如果仍然遇到问题

### 情况1: 系统代码未更新

```bash
# 拉取最新代码
cd /Users/jin/AI-Com/DeepCodeResearch
git pull  # 如果使用 Git

# 或手动检查 backend_core.py
grep -A 5 "_generate_pygame_project" backend_core.py | head -10
```

**应该看到**:
```python
def _generate_pygame_project(self, repo: Dict[str, str], design: Dict):
    """生成游戏项目 - 使用 tkinter (Python 标准库,无需额外依赖)"""
```

**如果看到的是**:
```python
def _generate_pygame_project(self, repo: Dict[str, str], design: Dict):
    """生成Pygame游戏项目"""  # ❌ 旧版本
```

需要更新代码!

### 情况2: 缓存问题

```bash
# 清除 Python 缓存
find . -type d -name "__pycache__" -exec rm -r {} + 2>/dev/null
find . -name "*.pyc" -delete

# 重启 Streamlit
streamlit run streamlit_app.py
```

### 情况3: API 调用返回了旧代码

如果 LLM 返回的代码中包含 pygame,备用生成器会自动替换为 tkinter 版本。

检查日志:
```bash
streamlit run streamlit_app.py 2>&1 | grep -i "警告\|fallback"
```

如果看到:
```
警告: LLM返回解析失败，使用备用方法重新生成
```

这是正常的,说明备用生成器正在工作。

## 技术说明

### 为什么改用 tkinter?

| pygame | tkinter |
|--------|---------|
| ❌ 需要安装 | ✅ Python 自带 |
| ❌ 需要 SDL2 库 | ✅ 无系统依赖 |
| ❌ macOS 安装复杂 | ✅ 跨平台开箱即用 |
| ❌ Docker 配置复杂 | ✅ Docker 友好 |

### tkinter 可用性

tkinter 在所有主流平台都是 Python 的标准组件:

- ✅ **Windows**: Python 安装自带
- ✅ **macOS**: Python 安装自带
- ✅ **Linux**: 大多数发行版自带,或 `apt install python3-tk`

### 验证 tkinter 可用

```bash
python -c "import tkinter; print('✅ tkinter 可用')"
```

如果报错,安装方法:

```bash
# macOS (通常不需要)
brew install python-tk

# Ubuntu/Debian
sudo apt-get install python3-tk

# CentOS/RHEL
sudo yum install python3-tkinter
```

## 总结

**问题**: 旧版本代码依赖 pygame,安装失败

**解决**:
1. ✅ 系统已修复,改用 tkinter
2. ✅ 重新生成代码即可
3. ✅ 新代码零依赖,直接运行

**验证**:
```bash
# 检查 requirements.txt
cat requirements.txt | grep -i pygame

# 如果没有输出 = ✅ 新版本
# 如果有 pygame = ❌ 需要重新生成
```

现在重新生成的代码完全不需要安装任何依赖!🎉
