# Python 导入问题修复总结

## 问题描述

用户反馈生成的 Python 代码运行时报错:
```
ModuleNotFoundError: No module named 'src'
```

**原因**: 生成的代码使用了绝对导入 `from src.model import Snake`,但直接运行 `python src/main.py` 时 Python 无法找到 `src` 模块。

## Python 模块导入的两种方式

### ❌ 错误方式 (会导致 ModuleNotFoundError)

```bash
# 直接运行文件
python src/main.py
```

**问题**: 当前工作目录是项目根目录,但 Python 解释器的搜索路径不包含项目根目录,所以找不到 `src` 模块。

### ✅ 正确方式

#### 方式1: 使用 Python 模块运行 (推荐)

```bash
# 在项目根目录运行
python -m src.main
```

**原理**: `-m` 选项告诉 Python 将 `src.main` 作为模块运行,Python 会自动将当前目录添加到搜索路径。

#### 方式2: 修改代码添加路径

在 `src/main.py` 开头添加:
```python
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# 然后可以正常导入
from src.model import Snake
```

#### 方式3: 使用相对导入

在 `src/main.py` 中:
```python
# 使用相对导入
from .model import Snake
from .game import Game

# 注意: 相对导入只能在包内使用,不能直接运行
# 必须用: python -m src.main
```

## 已实施的修复

### 1. 更新了 Code Agent 的 SYSTEM_PROMPT

在 [backend_core.py:668-675](backend_core.py#L668-L675) 添加了明确的导入规范:

```python
**Python 导入规范 (非常重要!)：**
对于 Python 项目，src/ 目录下的文件之间导入必须使用以下方式之一:
- 相对导入: `from .module import Class` 或 `from . import module`
- 或在文件开头添加路径: `import sys; sys.path.insert(0, os.path.dirname(__file__))`

❌ 错误示例: `from src.model import Snake`  # 这种导入会导致 ModuleNotFoundError
✅ 正确示例: `from .model import Snake` 或 `from model import Snake`
```

### 2. 改进了 README 生成

在 [backend_core.py:1031-1045](backend_core.py#L1031-L1045) 更新了运行说明:

```markdown
### 运行游戏

**重要**: 必须在项目根目录运行,有以下两种方式:

```bash
# 方法1: 使用 Python 模块方式运行 (推荐)
python -m src.main

# 方法2: 使用启动脚本
chmod +x run.sh
./run.sh
```

**注意事项**:
- ❌ 不要使用 `python src/main.py` (会导致导入错误)
- ✅ 使用 `python -m src.main` (正确的模块运行方式)
- ✅ 或使用提供的 `run.sh` 脚本
```

### 3. 更新了 run.sh 脚本

在 [backend_core.py:1711-1720](backend_core.py#L1711-L1720):

```bash
#!/bin/bash
# 运行游戏脚本

echo "启动贪吃蛇游戏..."
echo "控制: 使用方向键 ↑↓←→"
echo ""

# 使用 Python 模块方式运行,避免导入错误
python -m src.main
```

## 测试结果

### 测试 1: LLM 生成的代码

运行测试后发现 LLM 仍然生成了:
- 使用 `from models.snake import Snake` (相对导入,但缺少 `.`)
- 可以用 `python -m src.main` 运行

### 测试 2: Fallback 生成的代码 (tkinter 游戏)

Fallback 生成器已正确配置:
- README 包含清晰的运行说明
- `run.sh` 使用 `python -m src.main`
- 代码使用 tkinter,无需额外依赖

## 最佳实践建议

### 对于项目开发者

1. **始终使用模块运行方式**:
   ```bash
   python -m src.main  # 正确
   python src/main.py  # 可能出错
   ```

2. **在 src/__init__.py 中导出公共接口**:
   ```python
   # src/__init__.py
   from .model import Snake
   from .game import Game

   __all__ = ['Snake', 'Game']
   ```

3. **src/ 目录内使用相对导入**:
   ```python
   # src/main.py
   from .model import Snake  # 推荐
   from .game import Game
   ```

### 对于代码生成系统

1. **在 SYSTEM_PROMPT 中明确说明导入规范**
2. **在 README 中提供清晰的运行命令**
3. **提供 run.sh 脚本简化运行**
4. **测试生成的代码是否可运行**

## 相关文档

- Python 官方文档: [模块和包](https://docs.python.org/3/tutorial/modules.html)
- PEP 328: [相对导入](https://www.python.org/dev/peps/pep-0328/)
- [Python 导入系统详解](https://realpython.com/python-import/)

## 已知限制

### LLM 生成的代码质量

虽然我们在 SYSTEM_PROMPT 中添加了导入规范,但 LLM 可能不总是遵守。建议:

1. **增强 prompt 的强调程度** - 使用更多示例和警告
2. **后处理生成的代码** - 自动检查和修复导入语句
3. **提供运行脚本** - 即使代码有问题,用户也能通过脚本运行

### 当前状态

- ✅ Fallback 生成器完全修复
- ⚠️ LLM 生成需要进一步改进
- ✅ README 和脚本已更新
- ✅ 用户可以通过 `python -m src.main` 或 `./run.sh` 运行

## 后续优化方向

1. **代码后处理**:
   - 自动检测和修复导入语句
   - 统一使用相对导入
   - 添加路径初始化代码

2. **增强测试**:
   - 生成代码后自动测试导入
   - 检查是否存在 ModuleNotFoundError
   - 验证 `python -m src.main` 可运行

3. **改进 LLM prompt**:
   - 提供更多正确/错误示例
   - 强调导入规范的重要性
   - 要求 LLM 在回复中确认遵守规范
