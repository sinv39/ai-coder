#!/bin/bash
# DeepCodeResearch 快速启动脚本

echo "=========================================="
echo "DeepCodeResearch 启动脚本"
echo "=========================================="
echo ""

# 检查虚拟环境
if [ ! -d ".venv" ]; then
    echo "❌ 未找到虚拟环境 .venv"
    echo "请先运行: python -m venv .venv"
    exit 1
fi

# 激活虚拟环境
echo "🔧 激活虚拟环境..."
source .venv/bin/activate

# 检查 API Key
if [ -z "$DASHSCOPE_API_KEY" ]; then
    echo ""
    echo "⚠️  警告: 未配置 DASHSCOPE_API_KEY 环境变量"
    echo ""
    echo "配置步骤:"
    echo "1. 访问 https://bailian.console.aliyun.com/"
    echo "2. 获取 API Key"
    echo "3. 设置环境变量: export DASHSCOPE_API_KEY='your-api-key'"
    echo ""
    echo "你可以暂时运行应用查看界面,但无法生成代码"
    echo ""
    read -p "是否继续启动? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
else
    echo "✅ API Key 已配置"
fi

echo ""
echo "🚀 启动 Streamlit 应用..."
echo "访问: http://localhost:8501"
echo ""

# 启动 Streamlit
streamlit run streamlit_app.py
