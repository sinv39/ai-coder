#!/usr/bin/env python3
"""
测试改进后的 DeepCodeResearch 系统
验证:
1. 日志系统是否正常工作
2. LLM 调用是否被记录
3. 代码生成是否优先使用 LLM 而非 fallback
"""

import os
import sys
from pathlib import Path

# 确保在项目根目录
os.chdir(Path(__file__).parent)

from backend_core import DeepCodeResearchSystem

def test_simple_game():
    """测试生成简单游戏"""
    print("="*70)
    print("测试改进后的 DeepCodeResearch 系统")
    print("="*70)
    print()

    system = DeepCodeResearchSystem()

    # 测试需求: 生成一个简单的贪吃蛇游戏
    requirement = "写一个贪吃蛇游戏"

    print(f"需求: {requirement}")
    print()

    try:
        result = system.generate(
            user_input=requirement,
            input_type="text"
        )

        print()
        print("="*70)
        print("生成结果统计")
        print("="*70)

        code_repo = result['code_repo']
        metadata = result.get('metadata', {})

        print(f"✓ 状态: {result['status']}")
        print(f"✓ 生成文件数: {metadata.get('file_count', len(code_repo))} 个")
        print(f"✓ 代码总行数: {metadata.get('total_lines', 0)} 行")
        print(f"✓ 总耗时: {metadata.get('total_time', 0):.2f}s")
        print()

        print("生成的文件:")
        for i, file_path in enumerate(sorted(code_repo.keys()), 1):
            lines = len(code_repo[file_path].split('\n'))
            print(f"  {i}. {file_path} ({lines} 行)")

        print()
        print("="*70)
        print("日志文件位置")
        print("="*70)

        logs_dir = Path('logs')
        if logs_dir.exists():
            log_files = sorted(logs_dir.glob('*.log')) + sorted(logs_dir.glob('*.txt'))
            print(f"✓ logs/ 目录已创建")
            print(f"✓ 共 {len(log_files)} 个日志文件:")
            for log_file in log_files[:10]:  # 只显示前10个
                size = log_file.stat().st_size
                print(f"  - {log_file.name} ({size} bytes)")
            if len(log_files) > 10:
                print(f"  ... 还有 {len(log_files) - 10} 个文件")
        else:
            print("⚠️  logs/ 目录未创建")

        print()
        print("="*70)
        print("测试完成!")
        print("="*70)

        # 检查是否使用了 fallback
        print()
        print("检查代码生成方式:")

        # 查看 Code agent 的日志
        code_log = logs_dir / f'agent_code_{Path.cwd().stem}.log'
        if not code_log.exists():
            # 尝试查找今天的日志
            import datetime
            today = datetime.datetime.now().strftime('%Y%m%d')
            code_logs = list(logs_dir.glob(f'agent_code_{today}.log'))
            if code_logs:
                code_log = code_logs[0]

        if code_log and code_log.exists():
            with open(code_log, 'r', encoding='utf-8') as f:
                log_content = f.read()
                if '使用 fallback 生成器' in log_content or '⚠️' in log_content:
                    print("⚠️  使用了 fallback 生成器")
                    # 查找原因
                    for line in log_content.split('\n'):
                        if 'fallback' in line.lower() or '⚠️' in line:
                            print(f"    {line.strip()}")
                elif '✅ 使用 LLM 生成的代码' in log_content:
                    print("✅ 使用 LLM 生成的代码 (未使用 fallback)")
                else:
                    print("❓ 无法判断是否使用了 fallback")

        return True

    except Exception as e:
        print(f)
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_simple_game()
    sys.exit(0 if success else 1)
