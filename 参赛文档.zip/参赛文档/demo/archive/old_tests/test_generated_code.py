#!/usr/bin/env python3
"""
测试生成的代码是否能正常运行
"""

import os
import sys
import tempfile
import shutil
from pathlib import Path

def test_snake_game():
    """测试贪吃蛇游戏代码"""
    print("=" * 70)
    print("测试生成的贪吃蛇游戏代码")
    print("=" * 70)
    print()

    try:
        from backend_core import DeepCodeResearchSystem

        # 创建临时目录
        temp_dir = tempfile.mkdtemp(prefix='snake_test_')
        print(f"创建临时目录: {temp_dir}")
        print()

        try:
            # 生成代码
            print("1. 生成贪吃蛇游戏代码...")
            system = DeepCodeResearchSystem()
            result = system.generate('写一个贪吃蛇游戏', input_type='text')

            repo = result.get('code_repo', {})
            print(f"   ✓ 生成了 {len(repo)} 个文件")
            print()

            # 写入文件
            print("2. 写入文件到临时目录...")
            for file_path, content in repo.items():
                full_path = Path(temp_dir) / file_path
                full_path.parent.mkdir(parents=True, exist_ok=True)

                with open(full_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                print(f"   ✓ {file_path}")
            print()

            # 检查关键文件
            print("3. 检查关键文件...")
            required_files = [
                'README.md',
                'requirements.txt',
                'src/main.py',
                'src/game.py',
                'src/config.py',
                'tests/test_game.py'
            ]

            missing = []
            for file in required_files:
                if file in repo:
                    print(f"   ✓ {file}")
                else:
                    missing.append(file)
                    print(f"   ✗ {file} (缺失)")

            if missing:
                print(f"\n❌ 缺少 {len(missing)} 个关键文件")
                return False
            print()

            # 检查 README 内容
            print("4. 检查 README 内容...")
            readme = repo['README.md']

            checks = [
                ('包含项目名称', '# Snake Game' in readme or '# ' in readme),
                ('包含运行说明', 'python src/main.py' in readme),
                ('说明使用 tkinter', 'tkinter' in readme),
                ('说明零依赖', '零' in readme or '无需' in readme or '标准库' in readme),
                ('包含控制说明', 'Up' in readme or '↑' in readme),
            ]

            all_pass = True
            for check_name, result in checks:
                if result:
                    print(f"   ✓ {check_name}")
                else:
                    print(f"   ✗ {check_name}")
                    all_pass = False

            if not all_pass:
                print("\n⚠️  README 内容不完整")
                print("\nREADME 前500字符:")
                print(readme[:500])
                print()
            print()

            # 检查 requirements.txt
            print("5. 检查 requirements.txt...")
            requirements = repo['requirements.txt']

            if 'pygame' in requirements.lower():
                print("   ✗ 仍包含 pygame 依赖")
                return False
            elif '标准库' in requirements or '无需' in requirements or len(requirements.strip()) < 50:
                print("   ✓ 无外部依赖")
            else:
                print(f"   ⚠️  requirements.txt 内容: {requirements[:100]}")
            print()

            # 语法检查
            print("6. Python 语法检查...")
            python_files = [f for f in repo.keys() if f.endswith('.py')]

            syntax_errors = []
            for py_file in python_files:
                try:
                    compile(repo[py_file], py_file, 'exec')
                    print(f"   ✓ {py_file}")
                except SyntaxError as e:
                    syntax_errors.append((py_file, str(e)))
                    print(f"   ✗ {py_file}: {e}")

            if syntax_errors:
                print(f"\n❌ 发现 {len(syntax_errors)} 个语法错误")
                return False
            print()

            # 测试导入
            print("7. 测试模块导入...")
            sys.path.insert(0, str(Path(temp_dir) / 'src'))

            try:
                # 测试导入 config
                import config
                print("   ✓ import config")

                # 检查配置项
                required_configs = ['GRID_WIDTH', 'GRID_HEIGHT', 'CELL_SIZE', 'GAME_SPEED']
                for cfg in required_configs:
                    if hasattr(config, cfg):
                        print(f"   ✓ config.{cfg} = {getattr(config, cfg)}")
                    else:
                        print(f"   ✗ config.{cfg} 缺失")

                # 测试导入 game (不实例化,避免 tkinter 窗口)
                import game
                print("   ✓ import game")

                # 检查类定义
                if hasattr(game, 'Snake'):
                    print("   ✓ game.Snake 类存在")
                if hasattr(game, 'Food'):
                    print("   ✓ game.Food 类存在")
                if hasattr(game, 'SnakeGame'):
                    print("   ✓ game.SnakeGame 类存在")

            except Exception as e:
                print(f"   ✗ 导入失败: {e}")
                import traceback
                traceback.print_exc()
                return False
            finally:
                sys.path.remove(str(Path(temp_dir) / 'src'))
            print()

            # 运行单元测试
            print("8. 运行单元测试...")
            sys.path.insert(0, temp_dir)

            try:
                # 运行测试
                import unittest
                loader = unittest.TestLoader()
                suite = loader.discover(str(Path(temp_dir) / 'tests'))

                runner = unittest.TextTestRunner(verbosity=0)
                result = runner.run(suite)

                if result.wasSuccessful():
                    print(f"   ✓ 所有测试通过 ({result.testsRun} 个测试)")
                else:
                    print(f"   ⚠️  部分测试失败: {len(result.failures)} 失败, {len(result.errors)} 错误")
                    for test, traceback in result.failures + result.errors:
                        print(f"      - {test}: {traceback.split(chr(10))[0]}")
            except Exception as e:
                print(f"   ⚠️  测试运行失败: {e}")
            finally:
                sys.path.remove(temp_dir)
            print()

            print("=" * 70)
            print("✅ 代码生成测试通过!")
            print("=" * 70)
            print()
            print(f"生成的代码位于: {temp_dir}")
            print("可以手动运行:")
            print(f"  cd {temp_dir}")
            print(f"  python src/main.py")
            print()

            return True

        finally:
            # 可选: 清理临时目录
            # shutil.rmtree(temp_dir)
            pass

    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_snake_game()
    sys.exit(0 if success else 1)
