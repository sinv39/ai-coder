"""
测试 Streamlit 与后端集成
"""
import os
import sys

def check_api_key():
    """检查 API Key 配置"""
    api_key = os.getenv("DASHSCOPE_API_KEY")
    if api_key:
        print(f"✅ API Key 已配置 (前20字符): {api_key[:20]}...")
        return True
    else:
        print("❌ 未配置 DASHSCOPE_API_KEY 环境变量")
        print("\n配置步骤:")
        print("1. 访问 https://bailian.console.aliyun.com/")
        print("2. 获取 API Key")
        print("3. 设置环境变量: export DASHSCOPE_API_KEY='your-api-key'")
        return False

def check_dependencies():
    """检查依赖是否安装"""
    try:
        import streamlit
        print(f"✅ Streamlit 已安装 (版本: {streamlit.__version__})")
    except ImportError:
        print("❌ Streamlit 未安装")
        return False

    try:
        import openai
        print(f"✅ OpenAI 已安装")
    except ImportError:
        print("❌ OpenAI 未安装")
        return False

    try:
        import docx
        print(f"✅ python-docx 已安装")
    except ImportError:
        print("❌ python-docx 未安装")
        return False

    try:
        import PyPDF2
        print(f"✅ PyPDF2 已安装")
    except ImportError:
        print("❌ PyPDF2 未安装")
        return False

    return True

def check_backend():
    """检查后端模块"""
    try:
        from backend_core import DeepCodeResearchSystem
        print("✅ backend_core 模块可以正常导入")
        return True
    except Exception as e:
        print(f"❌ backend_core 导入失败: {e}")
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("DeepCodeResearch 集成测试")
    print("=" * 60)
    print()

    print("1. 检查依赖...")
    deps_ok = check_dependencies()
    print()

    print("2. 检查后端模块...")
    backend_ok = check_backend()
    print()

    print("3. 检查 API Key...")
    api_ok = check_api_key()
    print()

    print("=" * 60)
    if deps_ok and backend_ok:
        print("✅ 系统集成检查通过!")
        if not api_ok:
            print("⚠️  警告: API Key 未配置,需要配置后才能生成代码")
        print("\n启动命令: streamlit run streamlit_app.py")
    else:
        print("❌ 系统集成检查失败,请先解决上述问题")
        sys.exit(1)
    print("=" * 60)
