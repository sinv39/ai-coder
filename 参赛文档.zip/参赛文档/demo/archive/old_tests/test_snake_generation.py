#!/usr/bin/env python3
"""
测试贪吃蛇游戏代码生成
验证修复后的 repo-level 代码生成功能
"""

import os
import sys

def test_snake_generation_without_llm():
    """测试不依赖LLM的备用生成机制"""
    print("=" * 70)
    print("测试: 贪吃蛇游戏代码生成 (备用生成器)")
    print("=" * 70)
    print()

    try:
        from backend_core import DeepCodeResearchSystem
        from backend_core import AgentMessage, MessageType

        print("1. 创建系统实例...")
        system = DeepCodeResearchSystem()
        print("   ✓ 系统初始化成功")
        print()

        print("2. 构造设计文档(模拟 Design Agent 输出)...")
        design_doc = {
            "project_type": "游戏",
            "project_name": "Snake Game",
            "description": "经典贪吃蛇游戏",
            "tech_stack": {
                "language": "Python",
                "backend": "Pygame",
                "frontend": "",
                "database": ""
            },
            "modules": [
                {"name": "main", "description": "游戏主程序"},
                {"name": "game_logic", "description": "游戏逻辑"},
                {"name": "config", "description": "配置"}
            ],
            "architecture": {
                "pattern": "模块化设计"
            }
        }
        print("   ✓ 设计文档构造完成")
        print()

        print("3. 调用 CodeAgent 生成代码...")
        code_msg = AgentMessage(
            msg_type=MessageType.CODE_REQUEST,
            sender="Test",
            receiver="Code",
            content={"design_result": design_doc}
        )

        # 直接调用 CodeAgent
        repo = system.code.process(code_msg)

        print(f"   ✓ 代码生成完成! 共 {len(repo)} 个文件")
        print()

        print("4. 验证生成的文件...")
        expected_files = [
            'README.md',
            'requirements.txt',
            '.gitignore',
            'src/__init__.py',
            'src/main.py',
            'src/game.py',
            'src/config.py',
            'tests/__init__.py',
            'tests/test_game.py',
            'Dockerfile'
        ]

        missing_files = []
        for file in expected_files:
            if file in repo:
                content = repo[file]
                print(f"   ✓ {file:<25} ({len(content):>5} 字符)")
            else:
                missing_files.append(file)
                print(f"   ✗ {file:<25} (缺失!)")

        print()

        if missing_files:
            print(f"❌ 测试失败: 缺少 {len(missing_files)} 个文件")
            return False

        print("5. 验证核心文件内容...")

        # 检查 requirements.txt
        requirements = repo.get('requirements.txt', '')
        if 'pygame' in requirements.lower():
            print("   ✓ requirements.txt 包含 pygame")
        else:
            print("   ✗ requirements.txt 缺少 pygame 依赖")
            return False

        # 检查 main.py
        main_py = repo.get('src/main.py', '')
        if 'pygame.init()' in main_py and 'SnakeGame' in main_py:
            print(f"   ✓ src/main.py 包含完整的游戏主循环 ({len(main_py)} 字符)")
        else:
            print("   ✗ src/main.py 缺少关键代码")
            return False

        # 检查 game.py
        game_py = repo.get('src/game.py', '')
        if all(cls in game_py for cls in ['class Snake', 'class Food', 'class SnakeGame']):
            print(f"   ✓ src/game.py 包含 Snake/Food/SnakeGame 类 ({len(game_py)} 字符)")
        else:
            print("   ✗ src/game.py 缺少核心类")
            return False

        # 检查 config.py
        config_py = repo.get('src/config.py', '')
        if 'GRID_WIDTH' in config_py and 'COLOR' in config_py:
            print(f"   ✓ src/config.py 包含游戏配置 ({len(config_py)} 字符)")
        else:
            print("   ✗ src/config.py 缺少配置项")
            return False

        # 检查测试
        test_py = repo.get('tests/test_game.py', '')
        if 'test_snake' in test_py or 'def test_' in test_py:
            print(f"   ✓ tests/test_game.py 包含单元测试 ({len(test_py)} 字符)")
        else:
            print("   ✗ tests/test_game.py 缺少测试用例")

        print()
        print("=" * 70)
        print("✅ 测试通过! 代码生成功能正常工作")
        print("=" * 70)
        print()

        # 统计信息
        total_chars = sum(len(content) for content in repo.values())
        total_lines = sum(len(content.split('\n')) for content in repo.values())

        print("📊 生成代码统计:")
        print(f"   - 文件数量: {len(repo)}")
        print(f"   - 总字符数: {total_chars:,}")
        print(f"   - 总行数: {total_lines:,}")
        print()

        # 显示文件列表
        print("📁 生成的文件结构:")
        for file_path in sorted(repo.keys()):
            indent = "  " * file_path.count('/')
            name = file_path.split('/')[-1] if '/' in file_path else file_path
            print(f"{indent}├── {name}")

        print()
        return True

    except Exception as e:
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_with_full_system():
    """测试完整系统(需要API Key)"""
    print()
    print("=" * 70)
    print("测试: 完整系统端到端测试")
    print("=" * 70)
    print()

    api_key = os.getenv("DASHSCOPE_API_KEY")
    if not api_key:
        print("⚠️  跳过完整系统测试 (未配置 DASHSCOPE_API_KEY)")
        print()
        return None

    try:
        from backend_core import DeepCodeResearchSystem

        print("1. 创建系统...")
        system = DeepCodeResearchSystem()
        print("   ✓ 完成")
        print()

        print("2. 提交需求...")
        requirement = "写一个贪吃蛇游戏,使用 Pygame,支持方向键控制"
        print(f"   需求: {requirement}")
        print()

        print("3. 生成代码 (这可能需要几分钟)...")
        def callback(agent, status):
            print(f"   {agent}: {status}")

        result = system.generate(
            user_input=requirement,
            input_type="text",
            callback=callback
        )

        print()
        print("4. 验证结果...")
        if 'code_repo' in result:
            repo = result['code_repo']
            print(f"   ✓ 生成了 {len(repo)} 个文件")

            # 基础验证
            if 'src/game.py' in repo and len(repo['src/game.py']) > 100:
                print("   ✓ 包含完整的游戏代码")
                print()
                print("✅ 完整系统测试通过!")
                return True
            else:
                print("   ✗ 代码内容不完整")
                return False
        else:
            print("   ✗ 未生成代码仓库")
            return False

    except Exception as e:
        print(f"❌ 完整系统测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    print()
    print("🧪 DeepCodeResearch 代码生成测试")
    print()

    # 测试1: 不依赖LLM的备用生成
    test1_passed = test_snake_generation_without_llm()

    # 测试2: 完整系统(可选,需要API Key)
    test2_result = test_with_full_system()

    print()
    print("=" * 70)
    print("测试总结")
    print("=" * 70)
    print()
    print(f"✅ 备用生成器测试: {'通过' if test1_passed else '失败'}")
    if test2_result is not None:
        print(f"{'✅' if test2_result else '❌'} 完整系统测试: {'通过' if test2_result else '失败'}")
    else:
        print("⚠️  完整系统测试: 跳过 (需要 API Key)")
    print()

    if not test1_passed:
        sys.exit(1)
